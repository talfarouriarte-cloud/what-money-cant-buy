# Football beyond money — Paquete de migración (rediseño "Stadium Paper")
Generado: 2026-07-13

## Qué es
Rediseño completo de la app de https://footballbeyondmoney.uk (repo talfarouriarte-cloud/what-money-cant-buy).
Paridad funcional verificada contra el original: 12 vistas, i18n EN/ES, PWA, swipe, pull-to-refresh,
drag-scrub táctil en Matches, install prompt, GoatCounter, hash-params retrocompatibles.

## Despliegue (raíz de este paquete → raíz del hosting)
Archivos de producción (TODOS necesarios):
- index.html        — app completa, pre-transpilada (sin Babel en runtime). React/Recharts desde CDN.
- sw.js             — service worker (cache fbm-v2; network-first para .json/.html, cache-first resto)
- manifest.json     — PWA (start_url/scope "./", theme #C2492F)
- i18n.json         — strings [en, es]
- crests.json       — URLs de escudos
- fixtures.json     — calendario
- header-bg.jpeg    — hero del welcome
- icon-192.png, icon-512.png — iconos PWA

NO incluido: data.json. La app lo carga en runtime con fallbacks (en este orden):
  1. ./data.json  (mismo hosting — recomendado: el update.py diario ya lo genera ahí)
  2. https://footballbeyondmoney.uk/data.json
  3. raw.githubusercontent.com/.../develop/data.json

## Migración segura
1. Subir todo a un path de staging (p.ej. /v2/) y probar en móvil real:
   - gestos (swipe entre sub-vistas, drag-scrub en Matches, pull-to-refresh)
   - install prompt (Android: botón "Install app" en footer; iOS: instrucciones)
   - service worker: primera carga online, segunda offline
2. Los links antiguos NO se rompen: #tab=explorer → Overperformance, #tab=calc → Calculator, etc.
3. Al reemplazar el index.html viejo, el SW antiguo del dominio puede servir caché:
   este sw.js hace skipWaiting + clients.claim y borra caches ≠ fbm-v2, pero conviene
   verificar con hard-refresh. Si el SW viejo se registró con otro nombre de archivo, desregistrarlo.
4. GoatCounter ya apunta a footballbeyondmoney.goatcounter.com.

## Mantenimiento / futuras ediciones
index.html es un BUILD — no editarlo a mano. Fuentes en dev-src/:
- dev.html + src/*.jsx + styles.css + data.js  (shell modular con Babel standalone, para desarrollo)
- Para regenerar index.html: transpilar cada .jsx con Babel (preset react), envolver en IIFE
  exponiendo las funciones top-level en window (Object.assign(window, {fns})), e inlinear
  <style> (styles.css) + <script> (data.js) + los 6 bloques en este orden:
  tweaks-panel, primitives, Home, Tracker, tabs, app. Detalle en HANDOFF.md.
- Al cambiar assets cacheados, subir CACHE_NAME en sw.js (fbm-v3, ...).

## Pendiente de validar en producción
- SW / manifest / install prompt en dominio real (no comprobable en el preview del proyecto)
- data.json real: el rediseño consume el contrato completo incl. meta.wage_status
  (banner de salarios desactualizados) y pos[lg][sn].hist (evolución p50)

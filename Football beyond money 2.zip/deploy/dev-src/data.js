/* Football Beyond Money — data layer.
   Loads the REAL production data.json at runtime (no synthesis).
   data.json shape (authoritative, read from the deployed contract):
     model[lg]           = { beta, theta1, theta2 }              ordered-logit params
     seasons[lg][sn][tm] = { a[], e[], m[], gd, w, r[] }
        m[i] = [opp, isHome(1/0), ptsActual, ptsExpected]
        r[i] = [opp, isHome(1/0), pW, pD, pL, gw, "YYYY-MM-DD"]   upcoming
     bands[lg][tm]       = { p10[], p50[], p90[] }                updated forecast (cur season)
     pre[lg][tm]         = { p10[], p50[], p90[] }                budget forecast (cur season)
     pos[lg][sn]         = { pre:{tm:{1st,ucl,uel,conf,mid,rel,p50}}, cur:{...}, hist:[{probs:{tm:{p50}}}] }
     cumulative[lg][tm]  = overperformance record across seasons
     narratives[lg][tm]  = [en, es] bilingual outlook
     meta.wage_status[lg][sn] = "stale" | ...
   Leagues/zones are app constants (not in data.json). */

const LEAGUES = {
  ll: { name: "La Liga",        cur: "€", flag: "🇪🇸", def: "Barcelona",    n: 20, ucl: 4, uel: 2, ucol: 1, rel: 3, country: "ESP" },
  pl: { name: "Premier League", cur: "£", flag: "🇬🇧", def: "Liverpool",    n: 20, ucl: 4, uel: 2, ucol: 1, rel: 3, country: "ENG" },
  sa: { name: "Serie A",        cur: "€", flag: "🇮🇹", def: "Inter Milan",  n: 20, ucl: 4, uel: 2, ucol: 1, rel: 3, country: "ITA" },
  bl: { name: "Bundesliga",     cur: "€", flag: "🇩🇪", def: "Bayern Munich",n: 18, ucl: 4, uel: 2, ucol: 1, rel: 3, country: "GER" },
  l1: { name: "Ligue 1",        cur: "€", flag: "🇫🇷", def: "PSG",          n: 18, ucl: 4, uel: 1, ucol: 1, rel: 3, country: "FRA" },
  ed: { name: "Eredivisie",     cur: "€", flag: "🇳🇱", def: "Ajax",         n: 18, ucl: 2, uel: 1, ucol: 1, rel: 3, country: "NED" }
};
const LG_ORDER = ["pl", "ll", "sa", "bl", "l1", "ed"];

/* Position-zone boundaries per league (1-indexed, inclusive) — from the original ZONES constant.
   These drive the Tracker position-view background bands; note the 18-team leagues differ. */
const ZONES = {
  pl: { champion: [1, 1], ucl: [1, 4], uel: [5, 5], conf: [6, 6], rel: [18, 20] },
  ll: { champion: [1, 1], ucl: [1, 4], uel: [5, 5], conf: [6, 6], rel: [18, 20] },
  sa: { champion: [1, 1], ucl: [1, 4], uel: [5, 5], conf: [6, 6], rel: [18, 20] },
  bl: { champion: [1, 1], ucl: [1, 4], uel: [5, 6], conf: [7, 7], rel: [16, 18] },
  l1: { champion: [1, 1], ucl: [1, 4], uel: [5, 5], conf: [6, 6], rel: [16, 18] },
  ed: { champion: [1, 1], ucl: [1, 2], uel: [3, 3], conf: [4, 4], rel: [16, 18] }
};

/* Ordered-logit win/draw/loss from the model params and two wage bills.
   x = log2(wAway / wHome). Returns [pHome, pDraw, pAway]. */
function sigmoid(z) { return 1 / (1 + Math.exp(-z)); }
function probsFromModel(mod, wHome, wAway) {
  if (!mod || !(wHome > 0) || !(wAway > 0)) return [0.4, 0.26, 0.34];
  const x = Math.log2(wAway / wHome);
  const pH = 1 - sigmoid(mod.theta2 + mod.beta * x);
  const pD = sigmoid(mod.theta2 + mod.beta * x) - sigmoid(mod.theta1 + mod.beta * x);
  const pA = 1 - pH - pD;
  return [pH, pD, pA];
}

const DATA_URLS = [
  "data.json",
  "https://footballbeyondmoney.uk/data.json",
  "https://raw.githubusercontent.com/talfarouriarte-cloud/what-money-cant-buy/develop/data.json"
];

async function fetchFirst(urls, asJson) {
  let lastErr;
  for (const u of urls) {
    try {
      const res = await fetch(u, { mode: "cors" });
      if (!res.ok) throw new Error(u + " → " + res.status);
      return asJson ? await res.json() : res;
    } catch (e) { lastErr = e; }
  }
  throw lastErr;
}

async function buildDataset() {
  const [D, crests, i18n] = await Promise.all([
    fetchFirst(DATA_URLS, true),
    fetch("crests.json").then(r => r.json()).catch(() => ({})),
    fetch("i18n.json").then(r => r.json()).catch(() => ({}))
  ]);

  // i18n layer: strings are [en, es] arrays
  window.FBM_I18N = i18n;

  // currentSeason = latest season key present across leagues
  let currentSeason = "";
  Object.values(D.seasons || {}).forEach(lgSeasons => {
    Object.keys(lgSeasons).forEach(sn => { if (sn > currentSeason) currentSeason = sn; });
  });

  return {
    LEAGUES,
    LG_ORDER,
    ZONES,
    crests,
    model: D.model || {},
    seasons: D.seasons || {},
    bands: D.bands || {},
    pre: D.pre || {},
    pos: D.pos || {},
    cumulative: D.cumulative || {},
    narratives: D.narratives || {},
    meta: D.meta || {},
    currentSeason
  };
}

/* Expose */
window.FBM_LEAGUES = LEAGUES;
window.FBM_LG_ORDER = LG_ORDER;
window.FBM_ZONES = ZONES;
window.FBM_probs = probsFromModel;
window.FBM_buildDataset = buildDataset;

/* ---- i18n: [en, es] strings, lang from hash (#lang=) or localStorage, default en ---- */
function fbmLangFromHash() {
  const m = location.hash.match(/lang=(en|es)/);
  if (m) return m[1];
  try { return localStorage.getItem("fbm_lang") || "en"; } catch (e) { return "en"; }
}
window._lang = fbmLangFromHash();
window._li = () => (window._lang === "es" ? 1 : 0);
window._t = (key) => {
  const e = window.FBM_I18N && window.FBM_I18N[key];
  if (!e) return key;
  return e[window._li()] || e[0] || key;
};
window._tf = (key, vars) => {
  let s = window._t(key);
  if (vars) Object.keys(vars).forEach(k => { s = s.replace(new RegExp("\\{" + k + "\\}", "g"), vars[k]); });
  return s;
};
window.FBM_setLang = (lang) => {
  window._lang = lang;
  try { localStorage.setItem("fbm_lang", lang); } catch (e) {}
  const base = location.hash.replace(/[#&]?lang=(en|es)/, "").replace(/^#?/, "");
  location.hash = (base ? base + "&" : "tab=home&") + "lang=" + lang;
  location.reload();
};

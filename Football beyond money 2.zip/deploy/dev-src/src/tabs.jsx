/* Predictions, Matches, H2H, BadRun, Overperformance, Calculator, Methodology, Data, History */
const { useState, useMemo } = React;

/* ---------- Predictions — dual forecast from precomputed pos probabilities ---------- */

const FBM_ZONES_META = [
  { k: "p1",   lk: "col_1st",  c: "#D8C24A" },
  { k: "ucl",  lk: "col_ucl",  c: "#3D6EF7" },
  { k: "uel",  lk: "col_uel",  c: "#D8843D" },
  { k: "conf", lk: "col_conf", c: "#2FBF71" },
  { k: "mid",  lk: "col_mid",  c: "#9a938a" },
  { k: "rel",  lk: "col_rel",  c: "#E0503C" }
];

/* Map raw pos probabilities to mutually-exclusive zones.
   In the dataset `ucl` is cumulative (includes 1st); the app shows 1st and (ucl−1st) separately. */
function fbmExcl(p) {
  if (!p) return { p1: 0, ucl: 0, uel: 0, conf: 0, mid: 0, rel: 0 };
  return {
    p1: p["1st"] || 0,
    ucl: Math.max(0, (p.ucl || 0) - (p["1st"] || 0)),
    uel: p.uel || 0,
    conf: p.ucol || 0,
    mid: p.mid || 0,
    rel: p.rel || 0
  };
}

function ProbCell({ v, c }) {
  const pct = Math.round(v * 100);
  return (
    <td className="num" style={{ background: pct > 0 ? `color-mix(in srgb, ${c} ${Math.min(55, pct * 0.7)}%, transparent)` : "transparent" }}>
      {pct === 0 ? <span className="text-mut" style={{ opacity: 0.4 }}>–</span> : pct + "%"}
    </td>
  );
}

function Predictions({ lg, sn, team, setTeam }) {
  const D = window.__FBM.data;
  const sd = D.seasons[lg][sn] || {};
  const standings = useMemo(() => computeStandings(sd), [sd]);
  const L = window.FBM_LEAGUES[lg];
  const [open, setOpen] = useState(null); // expanded team
  const [budgetOpen, setBudgetOpen] = useState(false); // show all budget zone columns
  const isCurrent = sn === D.currentSeason;

  const posInfo = (D.pos[lg] && D.pos[lg][sn]) || {};
  const cur = posInfo.cur || {};
  const pre = posInfo.pre || {};
  // projected points p50: bands (updated) / pre (budget) last value — current season only
  const projPts = (name) => (isCurrent && D.bands[lg] && D.bands[lg][name]) ? D.bands[lg][name].p50[D.bands[lg][name].p50.length - 1] : null;
  const budgetPts = (name) => (isCurrent && D.pre[lg] && D.pre[lg][name]) ? D.pre[lg][name].p50[D.pre[lg][name].p50.length - 1] : null;

  return (
    <div className="col gap-4">
      <div className="section-head">
        <div>
          <div className="eyebrow">{L.name} · {sn}</div>
          <h2>{_t("tab_predictions")}</h2>
        </div>
      </div>
      <AboutTab infoKey="info_predictions" />

      <div className="card" style={{ padding: 0, overflow: "hidden" }}>
        <div className="scrollx">
          <table className="fbm predtable">
            <thead>
              <tr>
                <th colSpan="4" style={{ borderRight: "1px solid var(--hair-strong)" }}></th>
                <th colSpan="8" style={{ textAlign: "center", color: "var(--accent)", borderRight: "1px solid var(--hair-strong)" }}>{_t("updated_forecast")}</th>
                <th colSpan={budgetOpen ? 8 : 2} style={{ textAlign: "center" }}>
                  <button onClick={() => setBudgetOpen(!budgetOpen)}
                    style={{ background: "none", border: "none", font: "inherit", color: "inherit", textTransform: "inherit", letterSpacing: "inherit", display: "inline-flex", alignItems: "center", gap: 5 }}>
                    {_t("budget_forecast")}
                    <span style={{ fontSize: 9, transform: budgetOpen ? "rotate(90deg)" : "none", transition: "transform .15s", display: "inline-block" }}>▶</span>
                  </button>
                </th>
              </tr>
              <tr>
                <th className="rk">{_t("col_hash")}</th>
                <th>{_t("team")}</th>
                <THTip className="num" label={_t("col_gw")} tip={_t("tip_games_played")} />
                <THTip className="num" style={{ borderRight: "1px solid var(--hair-strong)" }} label={_t("col_pts")} tip={_t("tip_cur_actual")} />
                <THTip className="num" label={_t("col_cur_rk")} tip={_t("tip_cur_rk")} />
                <THTip className="num" label={_t("col_proj")} tip={_t("tip_cur_proj")} />
                <THTip className="num" label={_t("col_1st")} tip={_t("tip_cur_1st")} />
                <THTip className="num" label={_t("col_ucl")} tip={_t("tip_cur_ucl")} />
                <THTip className="num" label={_t("col_uel")} tip={_t("tip_cur_uel")} />
                <THTip className="num" label={_t("col_conf")} tip={_t("tip_cur_conf")} />
                <THTip className="num" label={_t("col_mid")} tip={_t("tip_cur_mid")} />
                <THTip className="num" style={{ borderRight: "1px solid var(--hair-strong)" }} label={_t("col_rel")} tip={_t("tip_cur_rel")} />
                <THTip className="num" label={_t("col_rk")} tip={_t("tip_budget_pre_rk")} />
                <THTip className="num" label={_t("col_exp")} tip={_t("tip_budget_pre_exp")} />
                {budgetOpen ? (
                  <>
                    <th className="num">{_t("col_1st")}</th>
                    <th className="num">{_t("col_ucl")}</th>
                    <th className="num">{_t("col_uel")}</th>
                    <th className="num">{_t("col_conf")}</th>
                    <th className="num">{_t("col_mid")}</th>
                    <th className="num">{_t("col_rel")}</th>
                  </>
                ) : null}
              </tr>
            </thead>
            <tbody>
              {standings.map((s, i) => {
                const u = fbmExcl(cur[s.n]), b = fbmExcl(pre[s.n]);
                const uRk = (cur[s.n] && cur[s.n].p50) || (i + 1);
                const bRk = (pre[s.n] && pre[s.n].p50) || null;
                const isOpen = open === s.n;
                const rkDelta = bRk != null ? bRk - uRk : 0; // positive = better than budget
                const pp = projPts(s.n), bp = budgetPts(s.n);
                return (
                  <React.Fragment key={s.n}>
                    <tr className={s.n === team ? "is-sel" : ""} onClick={() => setOpen(isOpen ? null : s.n)} style={{ cursor: "pointer" }}>
                      <td className="rk">{i + 1}</td>
                      <td>
                        <div className="team-cell pred-team">
                          <span style={{ color: "var(--muted)", fontSize: 10, width: 10, display: "inline-block", transform: isOpen ? "rotate(90deg)" : "none", transition: "transform .15s" }}>▶</span>
                          <Crest name={s.n} size={20} />
                          <span style={{ fontWeight: s.n === team ? 700 : 500, fontSize: 13 }}>{s.n}</span>
                        </div>
                      </td>
                      <td className="num">{s.played}</td>
                      <td className="num" style={{ borderRight: "1px solid var(--hair-strong)" }}><b>{s.pts}</b></td>
                      <td className="num" style={{ background: rkDelta > 0 ? "rgba(31,138,91,0.10)" : rkDelta < 0 ? "rgba(194,73,47,0.10)" : "transparent", fontWeight: 700 }}>{uRk}</td>
                      <td className="num text-mut">{pp != null ? Math.round(pp) : "–"}</td>
                      <ProbCell v={u.p1} c="#D8C24A" />
                      <ProbCell v={u.ucl} c="#3D6EF7" />
                      <ProbCell v={u.uel} c="#D8843D" />
                      <ProbCell v={u.conf} c="#2FBF71" />
                      <ProbCell v={u.mid} c="#9a938a" />
                      <td className="num" style={{ borderRight: "1px solid var(--hair-strong)", background: u.rel > 0.005 ? `rgba(224,80,60,${Math.min(0.5, u.rel)})` : "transparent" }}>
                        {u.rel < 0.005 ? <span className="text-mut" style={{ opacity: 0.4 }}>–</span> : Math.round(u.rel * 100) + "%"}
                      </td>
                      <td className="num text-mut">{bRk != null ? bRk : "–"}</td>
                      <td className="num text-mut">{bp != null ? Math.round(bp) : "–"}</td>
                      {budgetOpen ? (
                        <>
                          <ProbCell v={b.p1} c="#D8C24A" />
                          <ProbCell v={b.ucl} c="#3D6EF7" />
                          <ProbCell v={b.uel} c="#D8843D" />
                          <ProbCell v={b.conf} c="#2FBF71" />
                          <ProbCell v={b.mid} c="#9a938a" />
                          <ProbCell v={b.rel} c="#E0503C" />
                        </>
                      ) : null}
                    </tr>
                    {isOpen ? (
                      <tr>
                        <td colSpan={budgetOpen ? 20 : 14} style={{ padding: 0, background: "var(--bg-sunken)" }}>
                          <EvolutionChart posInfo={posInfo} team={s.n} lg={lg} sn={sn} />
                        </td>
                      </tr>
                    ) : null}
                  </React.Fragment>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

/* Stacked-area probability evolution for one team, read from pos.hist */
function EvolutionChart({ posInfo, team, lg, sn }) {
  const rows = useMemo(() => {
    const hist = (posInfo && posInfo.hist) || [];
    return hist.map(h => {
      const e = fbmExcl(h.probs && h.probs[team]);
      return { gw: h.gw, ...FBM_ZONES_META.reduce((o, z) => (o[z.k] = +(e[z.k] * 100).toFixed(1), o), {}) };
    });
  }, [posInfo, team]);

  if (!rows.length) return <div className="text-mut mono" style={{ padding: 20, fontSize: 11 }}>{_t("no_data_season")}</div>;
  return (
    <div style={{ padding: "14px 16px" }}>
      <div className="eyebrow" style={{ marginBottom: 10 }}>{team} · {_t("evolution_title")}</div>
      <div style={{ width: "100%", height: 180 }}>
        <Recharts.ResponsiveContainer>
          <Recharts.AreaChart data={rows} margin={{ top: 4, right: 10, bottom: 0, left: 0 }} stackOffset="expand">
            <Recharts.XAxis dataKey="gw" tickLine={false} axisLine={false} tick={{ fill: "var(--muted)", fontSize: 10 }} />
            <Recharts.YAxis tickFormatter={v => Math.round(v * 100) + "%"} tickLine={false} axisLine={false} tick={{ fill: "var(--muted)", fontSize: 10 }} width={38} />
            <Recharts.Tooltip
              contentStyle={{ background: "var(--bg-card)", border: "1px solid var(--hair-strong)", borderRadius: 10, fontSize: 12 }}
              labelFormatter={v => `${_t("col_gw")} ${v}`}
              formatter={(v, name) => [Math.round(v) + "%", _t((FBM_ZONES_META.find(z => z.k === name) || {}).lk || name)]}
            />
            {FBM_ZONES_META.map(z => (
              <Recharts.Area key={z.k} dataKey={z.k} stackId="1" stroke="none" fill={z.c} fillOpacity={0.75} isAnimationActive={false} />
            ))}
          </Recharts.AreaChart>
        </Recharts.ResponsiveContainer>
      </div>
      <div className="flex gap-3 center" style={{ fontSize: 11, marginTop: 8, flexWrap: "wrap", color: "var(--muted)" }}>
        {FBM_ZONES_META.map(z => (
          <span key={z.k} className="flex center gap-2"><span style={{ width: 10, height: 10, borderRadius: 2, background: z.c, opacity: 0.75 }} />{_t(z.lk)}</span>
        ))}
      </div>
    </div>
  );
}

/* ---------- Matches grid — probability-shaded matrix with result dots + inspection tooltip ---------- */
function Matches({ lg, sn, setTeam }) {
  const D = window.__FBM.data;
  const sd = D.seasons[lg][sn] || {};
  const L = window.FBM_LEAGUES[lg];
  // Teams sorted by wage bill, descending (original app behavior)
  const teams = useMemo(() => Object.keys(sd).sort((a, b) => (sd[b].w || 0) - (sd[a].w || 0)), [sd]);
  const [hover, setHover] = useState(null); // {h, a}
  const [pinned, setPinned] = useState(null);
  const wrapRef = React.useRef(null);
  const [tipPos, setTipPos] = useState({ x: 0, y: 0 });
  const isTouchDev = React.useRef(false);
  const touchRef = React.useRef({});
  const selFixRef = React.useRef(null);

  // responsive cell size: matrix must fit the container width (original behavior)
  const [wrapW, setWrapW] = useState(0);
  const [vw, setVw] = useState(typeof window !== "undefined" ? window.innerWidth : 1200);
  React.useEffect(() => {
    const measure = () => { if (wrapRef.current) setWrapW(wrapRef.current.clientWidth); setVw(window.innerWidth); };
    measure();
    window.addEventListener("resize", measure);
    return () => window.removeEventListener("resize", measure);
  }, []);
  const nT = teams.length || 20;
  // scale cells so the square matrix fills the card width completely
  const labelWide = wrapW >= (nT + 1) * 24 + 90;
  const labelW = labelWide ? 60 : 28;
  const fullBleed = vw <= 1024;
  const padX = fullBleed ? 8 : 24;
  const bleed = vw <= 720 ? 14 : 20;
  const cellSz = wrapW > 0 ? Math.max(12, Math.floor((wrapW - padX - labelW) / nT)) : 26;
  const compact = !labelWide;
  const crestSz = Math.max(10, Math.min(24, cellSz - 2));
  const dotSz = Math.max(5, Math.round(cellSz * 0.35));
  // re-measure after the full-bleed (negative margin) switch changes the card width
  React.useEffect(() => {
    if (wrapRef.current) setWrapW(wrapRef.current.clientWidth);
  }, [compact, fullBleed]);

  // suppress page scroll while dragging across grid cells
  React.useEffect(() => {
    const el = wrapRef.current;
    if (!el) return;
    const noScroll = (ev) => {
      let t = ev.target;
      while (t && t !== el) {
        if (t.tagName === "TD" || t.tagName === "TH") { ev.preventDefault(); return; }
        t = t.parentElement;
      }
    };
    el.addEventListener("touchmove", noScroll, { passive: false });
    return () => el.removeEventListener("touchmove", noScroll);
  }, []);

  // next matchday = earliest unplayed GW
  const nextGw = useMemo(() => {
    let g = Infinity;
    Object.values(sd).forEach(d => d.r.forEach(r => { if (r[5] < g) g = r[5]; }));
    return g;
  }, [sd]);

  const played = useMemo(() => {
    let p = 0, tot = 0;
    teams.forEach(h => { const d = sd[h]; p += d.m.filter(m => m[1] === 1).length; tot += d.m.filter(m => m[1] === 1).length + d.r.filter(r => r[1] === 1).length; });
    return { p, tot };
  }, [sd, teams]);

  // auto-highlight + pin the selected team's next fixture on mount / team change
  const selTeam = window.hashGet ? (window.hashGet("sel") || "").split(",")[0] : null;
  const [selFix, setSelFix] = useState(null);
  React.useEffect(() => {
    if (!selTeam || selFixRef.current === selTeam + "|" + sn) return;
    selFixRef.current = selTeam + "|" + sn;
    const td = sd[selTeam];
    if (!td || !td.r || !td.r[0]) return;
    const opp = td.r[0][0], isH = td.r[0][1] === 1;
    const h = isH ? selTeam : opp, a = isH ? opp : selTeam;
    if (!sd[h] || !sd[a]) return;
    setSelFix({ h, a });
    setPinned({ h, a, cx: 0, cy: 0 });
    requestAnimationFrame(() => requestAnimationFrame(() => {
      const wrap = wrapRef.current;
      const cell = wrap && wrap.querySelector(`td[data-cell="${CSS.escape(h)}|${CSS.escape(a)}"]`);
      if (!wrap || !cell) return;
      const wr = wrap.getBoundingClientRect(), cr = cell.getBoundingClientRect();
      const cx = cr.left - wr.left + cr.width / 2, cy = cr.top - wr.top + cr.height / 2;
      setPinned({ h, a, cx, cy });
      setTipPos({ x: Math.max(0, Math.min(cx + 20, wr.width - 244)), y: Math.max(0, Math.min(cy + 20, wr.height - 185)) });
    }));
  }, [sd, sn, selTeam]);

  // touch drag-scrub: slide finger across the grid, tooltip follows; lift pins
  const cellFromPoint = (x, y) => {
    const wrap = wrapRef.current;
    if (!wrap) return null;
    const tds = wrap.querySelectorAll("td[data-cell]");
    for (const td of tds) {
      const r = td.getBoundingClientRect();
      if (x >= r.left && x <= r.right && y >= r.top && y <= r.bottom) {
        const [h, a] = td.getAttribute("data-cell").split("|");
        return { h, a, rect: r };
      }
    }
    return null;
  };
  const onGridTouchStart = (ev) => {
    isTouchDev.current = true;
    const t = ev.touches[0];
    if (!t) return;
    touchRef.current = { sx: t.clientX, sy: t.clientY, moved: false, last: null };
  };
  const onGridTouchMove = (ev) => {
    const t = ev.touches[0];
    if (!t) return;
    const tr = touchRef.current;
    if (!tr.moved && Math.abs(t.clientX - tr.sx) + Math.abs(t.clientY - tr.sy) > 6) {
      tr.moved = true;
      setPinned(null);
    }
    if (!tr.moved) return;
    const c = cellFromPoint(t.clientX, t.clientY);
    tr.last = c;
    if (c) {
      setHover({ h: c.h, a: c.a });
      const wrap = wrapRef.current;
      const wr = wrap.getBoundingClientRect();
      setTipPos({ x: Math.max(0, Math.min(t.clientX - wr.left + 16, wr.width - 244)), y: Math.max(0, Math.min(t.clientY - wr.top + 16, wr.height - 185)) });
    }
  };
  const onGridTouchEnd = () => {
    const tr = touchRef.current;
    if (tr.moved && tr.last) {
      const wrap = wrapRef.current;
      const wr = wrap.getBoundingClientRect(), r = tr.last.rect;
      setPinned({ h: tr.last.h, a: tr.last.a, cx: r.left - wr.left + r.width / 2, cy: r.top - wr.top + r.height / 2 });
    } else if (tr.moved) {
      setHover(null);
    } else if (tr.sx != null) {
      // single tap: toggle pin on the tapped cell (original semantics)
      const c = cellFromPoint(tr.sx, tr.sy);
      if (c) {
        if (pinned && pinned.h === c.h && pinned.a === c.a) {
          setPinned(null); setHover(null);
        } else {
          const wrap = wrapRef.current;
          const wr = wrap.getBoundingClientRect(), r = c.rect;
          const cx = r.left - wr.left + r.width / 2, cy = r.top - wr.top + r.height / 2;
          setHover({ h: c.h, a: c.a });
          setPinned({ h: c.h, a: c.a, cx, cy });
          setTipPos({ x: Math.max(0, Math.min(cx + 16, wr.width - 244)), y: Math.max(0, Math.min(cy + 16, wr.height - 185)) });
        }
      } else if (pinned) {
        setPinned(null); setHover(null);
      }
    }
    touchRef.current = {};
  };

  const cell = (h, a) => {
    const hd = sd[h];
    const match = hd && hd.m.find(m => m[0] === a && m[1] === 1);
    if (match) return { match };
    const up = hd && hd.r.find(r => r[0] === a && r[1] === 1);
    if (up) return { up };
    return {};
  };

  const focus = pinned || hover;
  const focusCell = focus ? cell(focus.h, focus.a) : null;

  const onEnterCell = (h, a, ev) => {
    if (pinned) return;
    setHover({ h, a });
    moveTip(ev);
  };
  const moveTip = (ev) => {
    const wrap = wrapRef.current;
    if (!wrap) return;
    const r = wrap.getBoundingClientRect();
    // clamp so the tooltip (~230x170) never gets cut by the container edges
    const x = Math.max(0, Math.min(ev.clientX - r.left, r.width - 244));
    const y = Math.max(0, Math.min(ev.clientY - r.top, r.height - 185));
    setTipPos({ x, y });
  };
  const pinCell = (h, a, ev) => {
    if (pinned && pinned.h === h && pinned.a === a) { setPinned(null); return; }
    const wrap = wrapRef.current;
    let cx = 0, cy = 0;
    if (wrap && ev.currentTarget) {
      const wr = wrap.getBoundingClientRect();
      const cr = ev.currentTarget.getBoundingClientRect();
      cx = cr.left - wr.left + cr.width / 2;
      cy = cr.top - wr.top + cr.height / 2;
    }
    setPinned({ h, a, cx, cy });
    moveTip(ev);
  };

  const RES = { 3: "var(--pos)", 1: "var(--amber)", 0: "var(--neg)" };
  const model = D.model[lg];
  // model home-win probability for ANY pair (original semantics: every cell is shaded)
  const cellProbs = (h, a) => {
    const wH = sd[h] ? sd[h].w : 0, wA = sd[a] ? sd[a].w : 0;
    if (!model || !(wH > 0) || !(wA > 0)) return null;
    return window.FBM_probs(model, wH, wA);
  };

  // Biggest surprises: played matches ranked by |pts − model expected pts| (home perspective)
  const surprises = useMemo(() => {
    const out = [];
    teams.forEach(h => {
      const hd = sd[h];
      if (!hd || !hd.m) return;
      hd.m.forEach(m => {
        if (m[1] !== 1) return;
        const pr = cellProbs(h, m[0]);
        if (!pr) return;
        const exp = pr[0] * 3 + pr[1];
        out.push({ home: h, away: m[0], pts: m[2], diff: m[2] - exp, pW: pr[0], pD: pr[1], pL: pr[2], date: m[5] || "" });
      });
    });
    out.sort((a, b) => Math.abs(b.diff) - Math.abs(a.diff));
    return out.slice(0, 5);
  }, [sd, teams]);

  return (
    <div className="col gap-4">
      <div className="section-head">
        <div>
          <div className="eyebrow">{L.name} · {sn}</div>
          <h2>{_t("tab_matches")}</h2>
        </div>
        <div className="text-mut mono" style={{ fontSize: 12 }}>{played.p} {_t("played_of")} {played.tot}</div>
      </div>
      <AboutTab infoKey="info_matches" />
      <StaleBanner lg={lg} sn={sn} />
      <div ref={wrapRef} className="card" style={{ padding: fullBleed ? 4 : 12, overflow: fullBleed ? "visible" : "auto", position: "relative", ...(fullBleed ? { marginLeft: -bleed, marginRight: -bleed, borderRadius: 0, borderLeft: "none", borderRight: "none" } : {}) }}
        onMouseMove={e => { if (!pinned && hover && !isTouchDev.current) moveTip(e); }}
        onMouseLeave={() => { if (!pinned && !isTouchDev.current) setHover(null); }}
        onTouchStart={onGridTouchStart} onTouchMove={onGridTouchMove} onTouchEnd={onGridTouchEnd}>
        <table style={{ borderCollapse: "collapse", margin: "0 auto", tableLayout: "fixed", width: labelW + nT * cellSz }}>
          <thead>
            <tr>
              <th style={{ width: labelW, padding: 0 }}></th>
              {teams.map(t => (
                <th key={t} style={{ width: cellSz, padding: compact ? "2px 0" : "4px 1px", verticalAlign: "bottom", opacity: focus && focus.a !== t ? 0.35 : 1 }}>
                  <div className="col center" style={{ alignItems: "center", gap: compact ? 1 : 3 }}>
                    <Crest name={t} size={crestSz} />
                    {!compact ? <span className="mono text-mut" style={{ fontSize: 8 }}>{sd[t].w}</span> : null}
                  </div>
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {teams.map(h => (
              <tr key={h}>
                <td onClick={() => setTeam(h)} style={{ cursor: "pointer", padding: 0, height: cellSz, opacity: focus && focus.h !== h ? 0.35 : 1 }}>
                  <div className="flex center" style={{ gap: compact ? 2 : 6, justifyContent: "flex-end", paddingRight: 2 }}>
                    {!compact ? <span className="mono text-mut" style={{ fontSize: 9, width: 26, textAlign: "right" }}>{L.cur}{sd[h].w}M</span> : null}
                    <Crest name={h} size={crestSz} />
                  </div>
                </td>
                {teams.map(a => {
                  if (h === a) return <td key={a} style={{ width: cellSz, height: cellSz, padding: 0, background: "var(--bg-sunken)" }}></td>;
                  const c = cell(h, a);
                  const isFocus = focus && focus.h === h && focus.a === a;
                  const isNext = c.up && c.up[5] === nextGw;
                  const isSelFix = selFix && selFix.h === h && selFix.a === a;
                  // probability shading on every cell (original heatmap)
                  const pr = cellProbs(h, a);
                  let bg = "transparent";
                  if (pr) {
                    if (pr[0] > 0.5) bg = `rgba(46,139,87,${Math.min(0.55, (pr[0] - 0.5) * 1.2 + 0.1).toFixed(3)})`;
                    else if (pr[2] > 0.5) bg = `rgba(192,57,43,${Math.min(0.55, (pr[2] - 0.5) * 1.2 + 0.1).toFixed(3)})`;
                    else bg = "rgba(200,180,50,0.18)";
                  }
                  const common = {
                    "data-cell": h + "|" + a,
                    onMouseEnter: (e) => { if (!isTouchDev.current) onEnterCell(h, a, e); },
                    onClick: (e) => { if (!isTouchDev.current) pinCell(h, a, e); },
                    style: {
                      width: cellSz, height: cellSz, minWidth: cellSz, maxHeight: cellSz, lineHeight: 0, textAlign: "center", cursor: "pointer", padding: 0,
                      border: "1px solid var(--hair)",
                      background: bg,
                      touchAction: "none",
                      // cross-highlight: home team's row + away team's column stay full, rest dims
                      opacity: focus && !(h === focus.h || a === focus.a) ? 0.30 : 1,
                      outline: isFocus ? "2px solid var(--ink)" : isSelFix ? "2.5px solid var(--amber)" : isNext ? `2px solid ${c.up[2] > c.up[4] ? "var(--pos)" : "var(--neg)"}` : "none",
                      outlineOffset: -2
                    }
                  };
                  if (c.match) {
                    return (
                      <td key={a} {...common}>
                        <span style={{ display: "inline-block", width: dotSz + 2, height: dotSz + 2, borderRadius: dotSz, background: RES[c.match[2]] }}></span>
                      </td>
                    );
                  }
                  return (
                    <td key={a} {...common}>
                      {pr && cellSz >= 16 ? <span className="mono" style={{ fontSize: Math.min(11, cellSz * 0.4), fontWeight: 600, lineHeight: 1, verticalAlign: "middle", color: "var(--ink-soft)" }}>{Math.round(pr[0] * 100)}</span> : null}
                    </td>
                  );
                })}
              </tr>
            ))}
          </tbody>
        </table>

        {pinned ? (
          <svg style={{ position: "absolute", left: 0, top: 0, width: "100%", height: "100%", pointerEvents: "none", zIndex: 9 }}>
            <line x1={pinned.cx} y1={pinned.cy} x2={tipPos.x + 14} y2={tipPos.y + 14} stroke="var(--ink)" strokeWidth="1.5" strokeDasharray="4 3" opacity="0.7" />
            <circle cx={pinned.cx} cy={pinned.cy} r="3" fill="var(--ink)" />
          </svg>
        ) : null}

        {focus && focusCell && (focusCell.match || focusCell.up || cellProbs(focus.h, focus.a)) ? (
          <MatchTip focus={focus} c={focusCell} sd={sd} L={L} pos={tipPos} pinned={!!pinned} onClose={() => { setPinned(null); setHover(null); }} model={model} />
        ) : null}
      </div>
      <div className="flex gap-4 center text-mut" style={{ fontSize: 11, padding: "0 8px", flexWrap: "wrap" }}>
        <span className="flex center gap-2"><span style={{ width: 9, height: 9, borderRadius: 5, background: "var(--pos)" }} /> {_t("legend_home_win")}</span>
        <span className="flex center gap-2"><span style={{ width: 9, height: 9, borderRadius: 5, background: "var(--amber)" }} /> {_t("legend_draw")}</span>
        <span className="flex center gap-2"><span style={{ width: 9, height: 9, borderRadius: 5, background: "var(--neg)" }} /> {_t("legend_away_win")}</span>
        <span className="flex center gap-2"><span className="mono" style={{ fontSize: 9, padding: "1px 4px", background: "rgba(31,138,91,0.3)", borderRadius: 3 }}>NN</span> {_t("legend_unplayed")} · {_t("home_win_pct")}</span>
        <span className="flex center gap-2"><span style={{ width: 12, height: 12, border: "2px solid var(--pos)", borderRadius: 3 }} /> {_t("next_matchday")}</span>
      </div>

      {surprises.length > 0 ? (
        <div className="card" style={{ padding: 18 }}>
          <div className="eyebrow" style={{ marginBottom: 10 }}>{_t("surprises")}</div>
          <div className="col" style={{ gap: 0 }}>
            {surprises.map((s, i) => {
              const clr = s.pts === 3 ? "var(--pos)" : s.pts === 1 ? "var(--amber)" : "var(--neg)";
              const lbl = s.pts === 3 ? _t("w_short") : s.pts === 1 ? _t("d_short") : _t("l_short");
              return (
                <div key={i} className="flex center" style={{ gap: 8, padding: "6px 0", borderBottom: i < surprises.length - 1 ? "1px solid var(--hair)" : "none", fontSize: 12, flexWrap: "wrap" }}>
                  <span style={{ width: 8, height: 8, borderRadius: 4, background: clr, flexShrink: 0 }}></span>
                  <span className="flex center" style={{ gap: 4 }}>
                    <Crest name={s.home} size={14} /> <b>{s.home}</b> <span className="text-mut">vs</span> <Crest name={s.away} size={14} /> {s.away}
                  </span>
                  <span style={{ color: clr, fontWeight: 700 }}>{lbl}</span>
                  <span className="text-mut mono" style={{ fontSize: 11 }}>({_t("exp_short")} {Math.round(s.pW * 100)}% {_t("w_short")} / {Math.round(s.pD * 100)}% {_t("d_short")} / {Math.round(s.pL * 100)}% {_t("l_short")})</span>
                  {s.date ? <span className="text-mut" style={{ fontSize: 11, opacity: 0.7 }}>{s.date}</span> : null}
                </div>
              );
            })}
          </div>
        </div>
      ) : null}
    </div>
  );
}

function MatchTip({ focus, c, sd, L, pos, pinned, onClose, model }) {
  const { h, a } = focus;
  const m = c.match, up = c.up;
  const date = m ? m[5] : up ? up[6] : null;
  const border = m ? (m[2] === 3 ? "var(--pos)" : m[2] === 1 ? "var(--amber)" : "var(--neg)") : "var(--hair-strong)";
  const wH = sd[h] ? sd[h].w : 0, wA = sd[a] ? sd[a].w : 0;
  // model W/D/L: from r[] for unplayed fixtures, recomputed from wages otherwise (original semantics)
  const probs = up ? [up[2], up[3], up[4]] : (model && wH > 0 && wA > 0 ? window.FBM_probs(model, wH, wA) : null);
  return (
    <div
      onClick={onClose}
      onTouchEnd={(e) => { e.stopPropagation(); e.preventDefault(); onClose(); }}
      style={{
        position: "absolute", left: pos.x + 14, top: pos.y + 14, zIndex: 10,
        background: "var(--bg-card)", border: "1px solid var(--hair-strong)", borderLeft: `4px solid ${border}`, borderRadius: 10,
        boxShadow: "0 10px 30px rgba(0,0,0,0.14)", padding: "10px 12px", minWidth: 210, maxWidth: "calc(100vw - 40px)",
        pointerEvents: "auto", cursor: "pointer"
      }}>
      <div className="flex between center" style={{ gap: 10, marginBottom: 4 }}>
        <div className="flex center gap-2">
          <Crest name={h} size={18} /><span style={{ fontWeight: 700, fontSize: 13 }}>{h}</span>
          <span className="text-mut" style={{ fontSize: 11 }}>{_t("vs")}</span>
          <span style={{ fontWeight: 700, fontSize: 13 }}>{a}</span><Crest name={a} size={18} />
        </div>
        {pinned ? <button onClick={onClose} style={{ border: "none", background: "none", color: "var(--muted)", fontSize: 14, padding: 0 }}>×</button> : null}
      </div>
      {wH > 0 && wA > 0 ? (
        <div className="mono text-mut" style={{ fontSize: 10, marginBottom: 2 }}>{L.cur}{wH}M {_t("vs")} {L.cur}{wA}M</div>
      ) : null}
      {date ? <div className="mono text-mut" style={{ fontSize: 10, marginBottom: 4 }}>{dateNice(date)} · {_t("col_gw")} {m ? m[4] : up[5]}</div> : null}
      {probs ? (
        <div className="flex gap-3 mono" style={{ fontSize: 11 }}>
          <span style={{ color: "var(--pos)", fontWeight: 600 }}>{_t("w_short")} {Math.round(probs[0] * 100)}%</span>
          <span style={{ color: "var(--amber)", fontWeight: 600 }}>{_t("d_short")} {Math.round(probs[1] * 100)}%</span>
          <span style={{ color: "var(--neg)", fontWeight: 600 }}>{_t("l_short")} {Math.round(probs[2] * 100)}%</span>
        </div>
      ) : null}
      {m ? (
        <div style={{ fontSize: 11, marginTop: 4, color: "var(--ink-soft)" }}>
          {_t("actual_vs")}{m[2]} {_t("pts_lc")} <span className="text-mut">({_t("exp_short")} {m[3].toFixed(1)})</span>
        </div>
      ) : null}
    </div>
  );
}

/* ---------- Head to Head ---------- */
function H2H({ lg, sn, team }) {
  const D = window.__FBM.data;
  const sd = D.seasons[lg][sn] || {};
  const L = window.FBM_LEAGUES[lg];
  const standings = useMemo(() => computeStandings(sd), [sd]);
  const initialB = standings.find(s => s.n !== team)?.n;
  const [b, setB] = useState(() => {
    const h = window.hashGet && window.hashGet("h2b");
    return (h && sd[h] && h !== team) ? h : initialB;
  });
  React.useEffect(() => { if (b && window.hashSet) window.hashSet({ h2b: b }); }, [b]);
  const [win, setWin] = useState("all");

  React.useEffect(() => {
    if (!sd[b]) setB(initialB);
  }, [lg, sn, team]);

  const a = team;
  if (!sd[a] || !sd[b]) return null;

  // All meetings across seasons (window-filtered), newest first
  const meetings = useMemo(() => {
    const nSeasons = win === "10y" ? 10 : win === "5y" ? 5 : win === "3y" ? 3 : 99;
    const out = [];
    const seasons = Object.keys(D.seasons[lg]).sort().reverse().slice(0, nSeasons);
    const md = D.model[lg];
    seasons.forEach(s => {
      const sdd = D.seasons[lg][s];
      const td = sdd && sdd[a];
      if (!td || !sdd[b]) return;
      td.m.forEach(m => {
        if (m[0] !== b) return;
        const isH = m[1] === 1;
        const pA = m[2], eA = m[3];
        const pB = pA === 3 ? 0 : pA === 1 ? 1 : 3;
        // expected for B from that season's wages
        const wAs = td.w || 0, wBs = sdd[b].w || 0;
        let eB = null, pwA = null, pdM = null, pwB = null;
        if (md && wAs > 0 && wBs > 0) {
          const pp = window.FBM_probs(md, isH ? wAs : wBs, isH ? wBs : wAs);
          const pv = isH ? pp : [pp[2], pp[1], pp[0]]; // from A's perspective
          pwA = Math.round(pv[0] * 100); pdM = Math.round(pv[1] * 100); pwB = Math.round(pv[2] * 100);
          eB = 3 * pv[2] + pv[1];
        }
        out.push({ sn: s, hm: isH ? a : b, home: isH, pA, pB, eA, eB: eB != null ? eB : 3 - eA > 0 ? +(3 * (1 - eA / 3)).toFixed(2) : 0, pwA, pdM, pwB, date: m[5] });
      });
    });
    return out;
  }, [a, b, lg, win]);

  // Summary: total + per-venue (from A's perspective)
  const sm = useMemo(() => {
    let wA = 0, wB = 0, dr = 0, tpA = 0, tpB = 0, teA = 0, teB = 0;
    const mk = () => ({ w: 0, d: 0, l: 0, n: 0, tp: 0, te: 0 });
    const hmA = mk(), hmB = mk();
    meetings.forEach(m => {
      if (m.pA === 3) wA++; else if (m.pA === 0) wB++; else dr++;
      tpA += m.pA; tpB += m.pB; teA += m.eA; teB += m.eB;
      const v = m.home ? hmA : hmB;
      // per-venue record from A's perspective
      if (m.pA === 3) v.w++; else if (m.pA === 1) v.d++; else v.l++;
      v.n++; v.tp += m.pA; v.te += m.eA;
    });
    return { wA, wB, dr, n: meetings.length, tpA, tpB, teA: +teA.toFixed(1), teB: +teB.toFixed(1), hmA, hmB };
  }, [meetings]);

  // Cumulative points (oldest → newest)
  const cumD = useMemo(() => {
    let cA = 0, cB = 0, ceA = 0, ceB = 0;
    return meetings.slice().reverse().map(m => {
      cA += m.pA; cB += m.pB; ceA += m.eA; ceB += m.eB;
      return { lb: m.sn + (m.hm === a ? ` (${_t("home_lbl")})` : ` (${_t("away_lbl")})`), cA, cB, eA: +ceA.toFixed(1), eB: +ceB.toFixed(1), pA: m.pA, pB: m.pB, pwA: m.pwA, pdM: m.pdM, pwB: m.pwB, sn: m.sn };
    });
  }, [meetings, a]);

  const wagesA = sd[a].w, wagesB = sd[b].w;
  const model = D.model[lg];
  const hasModel = model && wagesA > 0 && wagesB > 0;
  // Model probs for each venue from current wages (A home / B home), A's perspective
  const pAH = hasModel ? window.FBM_probs(model, wagesA, wagesB) : null; // [P(A win), draw, P(B win)] with A home
  const pBH = hasModel ? window.FBM_probs(model, wagesB, wagesA) : null; // with B home: [P(B win), draw, P(A win)]
  // Weighted total from A's perspective
  let totM = null;
  if (hasModel && sm.hmA.n + sm.hmB.n > 0) {
    const nA = sm.hmA.n, nB = sm.hmB.n, nT = nA + nB;
    totM = [
      Math.round((pAH[0] * nA + pBH[2] * nB) / nT * 100),
      Math.round((pAH[1] * nA + pBH[1] * nB) / nT * 100),
      Math.round((pAH[2] * nA + pBH[0] * nB) / nT * 100)
    ];
  }

  const CLR_A = "var(--cobalt)", CLR_B = "#D8843D";

  const Pill = ({ val, sub, clr, mute }) => (
    <div style={{ flex: 1, borderRadius: 6, padding: "3px 0", textAlign: "center", minWidth: 26, background: mute ? "var(--bg-sunken)" : clr + "1a" }}>
      <div style={{ fontWeight: 700, fontSize: 12, color: mute ? "var(--muted)" : clr }}>{val}</div>
      {sub != null ? <div style={{ fontSize: 8, color: "var(--muted)" }}>{sub}</div> : null}
    </div>
  );
  const PillRow = ({ label, mWDL, rec }) => {
    const pc = (v) => rec.n > 0 ? Math.round(v / rec.n * 100) : 0;
    const diff = rec.tp - rec.te;
    return (
      <div className="flex center" style={{ gap: 10, padding: "10px 0", borderBottom: "1px solid var(--hair)", flexWrap: "wrap" }}>
        <div style={{ width: 84, flexShrink: 0, fontWeight: 600, fontSize: 12 }}>{label}</div>
        <div style={{ flex: 1, minWidth: 170 }}>
          <div className="flex center" style={{ gap: 4, marginBottom: 4 }}>
            <span className="mono" style={{ fontSize: 8, color: "var(--muted)", width: 38, flexShrink: 0 }}>{_t("model_lbl")}</span>
            <Pill val={mWDL ? mWDL[0] + "%" : "—"} sub={_t("w_short")} clr="var(--pos)" mute={!mWDL} />
            <Pill val={mWDL ? mWDL[1] + "%" : "—"} sub={_t("d_short")} clr="var(--muted)" mute={!mWDL} />
            <Pill val={mWDL ? mWDL[2] + "%" : "—"} sub={_t("l_short")} clr="var(--neg)" mute={!mWDL} />
          </div>
          <div className="flex center" style={{ gap: 4 }}>
            <span className="mono" style={{ fontSize: 8, color: "var(--muted)", width: 38, flexShrink: 0 }}>{_t("h2h_record")}</span>
            <Pill val={pc(rec.w) + "%"} sub={rec.w} clr="var(--pos)" />
            <Pill val={pc(rec.d) + "%"} sub={rec.d} clr="var(--muted)" />
            <Pill val={pc(rec.l) + "%"} sub={rec.l} clr="var(--neg)" />
          </div>
        </div>
        <div style={{ width: 76, flexShrink: 0, textAlign: "right" }}>
          <div style={{ fontSize: 12 }}><b style={{ color: CLR_A }}>{rec.tp}</b><span className="text-mut"> / {(+rec.te).toFixed(1)}</span></div>
          <div style={{ fontSize: 12, fontWeight: 700, color: diff >= 0 ? "var(--pos)" : "var(--neg)" }}>{(diff >= 0 ? "+" : "") + diff.toFixed(1)}</div>
          <div style={{ fontSize: 9, color: "var(--muted)" }}>{rec.n} {_t("matches_lc")}</div>
        </div>
      </div>
    );
  };

  const h2hTip = (tp) => {
    if (!tp.active || !tp.payload || !tp.payload.length) return null;
    const d = tp.payload[0].payload;
    const wonA = d.pA === 3, wonB = d.pB === 3;
    const clrA = wonA ? "var(--pos)" : wonB ? "var(--neg)" : "var(--amber)";
    const clrB = wonB ? "var(--pos)" : wonA ? "var(--neg)" : "var(--amber)";
    const bd = wonA ? CLR_A : wonB ? CLR_B : "var(--hair-strong)";
    const sdH = D.seasons[lg][d.sn];
    const wA2 = sdH && sdH[a] ? sdH[a].w : 0, wB2 = sdH && sdH[b] ? sdH[b].w : 0;
    return (
      <div className="charttip" style={{ borderLeft: `4px solid ${bd}` }}>
        <div style={{ fontWeight: 700, marginBottom: 3 }}>{d.lb}</div>
        {wA2 > 0 && wB2 > 0 ? <div className="mono text-mut" style={{ fontSize: 10, marginBottom: 3 }}>{L.cur}{wA2}M {_t("vs")} {L.cur}{wB2}M</div> : null}
        <div className="flex between center" style={{ gap: 12, background: clrA + "22", borderRadius: 4, padding: "3px 6px", marginBottom: 2 }}>
          <span className="flex center gap-2"><Crest name={a} size={12} /><span style={{ fontWeight: 600 }}>{a}</span></span>
          <span><b>{d.cA}</b>{d.pwA != null ? <span className="text-mut"> · {d.pwA}%</span> : null}</span>
        </div>
        <div className="flex between center" style={{ gap: 12, background: clrB + "22", borderRadius: 4, padding: "3px 6px", marginBottom: 2 }}>
          <span className="flex center gap-2"><Crest name={b} size={12} /><span style={{ fontWeight: 600 }}>{b}</span></span>
          <span><b>{d.cB}</b>{d.pwB != null ? <span className="text-mut"> · {d.pwB}%</span> : null}</span>
        </div>
        {d.pdM != null ? <div style={{ textAlign: "center", fontSize: 9, color: "var(--muted)" }}>{_t("draw")} {d.pdM}%</div> : null}
      </div>
    );
  };

  return (
    <div className="col gap-4">
      <div className="section-head">
        <div>
          <div className="eyebrow">{_t("tab_h2h")}</div>
          <h2>{a} {_t("vs")} <select value={b} onChange={e => setB(e.target.value)} className="field" style={{ height: 42, fontSize: 20, fontFamily: "var(--font-display)", fontWeight: 600 }}>
            {Object.keys(sd).filter(n => n !== a).map(n => <option key={n} value={n}>{n}</option>)}
          </select></h2>
          <AboutTab infoKey="info_h2h" />
        </div>
        <div className="flex gap-2">
          {["all", "10y", "5y", "3y"].map(w => (
            <button key={w} onClick={() => setWin(w)} className={"chip " + (win === w ? "is-active" : "")}>{w === "all" ? _t("all") : w}</button>
          ))}
        </div>
      </div>

      <div className="card" style={{ padding: 28 }}>
        <div className="h2h-hero" style={{ display: "grid", gridTemplateColumns: "1fr auto 1fr", alignItems: "center", gap: 28 }}>
          <div style={{ textAlign: "center" }}>
            <Crest name={a} size={72} />
            <div className="display" style={{ fontSize: 26, marginTop: 12, color: CLR_A }}>{a}</div>
            <div className="mono text-mut" style={{ fontSize: 11, marginTop: 4 }}>{L.cur}{wagesA}M · #{1 + standings.findIndex(s => s.n === a)}</div>
          </div>
          <div style={{ textAlign: "center" }}>
            <div className="bignum mono">{sm.wA}<span className="text-mut">·{sm.dr}·</span>{sm.wB}</div>
            <div className="eyebrow" style={{ marginTop: 6 }}>{_t("h2h_record")} · {sm.n}{_t("matches_lc")}</div>
          </div>
          <div style={{ textAlign: "center" }}>
            <Crest name={b} size={72} />
            <div className="display" style={{ fontSize: 26, marginTop: 12, color: CLR_B }}>{b}</div>
            <div className="mono text-mut" style={{ fontSize: 11, marginTop: 4 }}>{L.cur}{wagesB}M · #{1 + standings.findIndex(s => s.n === b)}</div>
          </div>
        </div>
      </div>

      {/* Model vs history by venue — from A's perspective */}
      <div className="card" style={{ padding: "12px 20px 4px" }}>
        <div className="flex center gap-2" style={{ fontSize: 12, marginBottom: 4, flexWrap: "wrap" }}>
          <Crest name={a} size={14} /><b style={{ color: CLR_A }}>{a}</b> {_t("vs")} <Crest name={b} size={14} /><b style={{ color: CLR_B }}>{b}</b>
          <span className="text-mut">— {_t("h2h_from_perspective")} </span><span style={{ color: CLR_A, fontWeight: 600 }}>{a}</span>
        </div>
        {sm.hmA.n > 0 ? <PillRow label={(window._lang === "es" ? "En casa " + a : a + " home")} mWDL={hasModel ? [Math.round(pAH[0] * 100), Math.round(pAH[1] * 100), Math.round(pAH[2] * 100)] : null} rec={sm.hmA} /> : null}
        {sm.hmB.n > 0 ? <PillRow label={(window._lang === "es" ? "En casa " + b : b + " home")} mWDL={hasModel ? [Math.round(pBH[2] * 100), Math.round(pBH[1] * 100), Math.round(pBH[0] * 100)] : null} rec={sm.hmB} /> : null}
        <PillRow label={_t("total")} mWDL={totM} rec={{ w: sm.wA, d: sm.dr, l: sm.wB, n: sm.n, tp: sm.tpA, te: sm.teA }} />
      </div>

      {meetings.length === 0 ? (
        <div className="card text-mut" style={{ padding: 24, textAlign: "center" }}>{_t("no_matches")}</div>
      ) : (
        <>
          {/* Cumulative points chart */}
          <div className="card" style={{ padding: 18 }}>
            <div className="eyebrow" style={{ marginBottom: 12 }}>{_t("cumulative_points")}</div>
            <div style={{ width: "100%", height: 280 }}>
              <Recharts.ResponsiveContainer>
                <Recharts.LineChart data={cumD} margin={{ top: 5, right: 8, bottom: 30, left: 0 }}>
                  <Recharts.CartesianGrid stroke="var(--hair)" strokeDasharray="2 4" vertical={false} />
                  <Recharts.XAxis dataKey="lb" tick={{ fill: "var(--muted)", fontSize: 9, angle: -35, textAnchor: "end" }} height={55} interval={Math.max(0, Math.floor(cumD.length / 10) - 1)} tickLine={false} axisLine={false} />
                  <Recharts.YAxis tick={{ fill: "var(--muted)", fontSize: 10 }} tickLine={false} axisLine={false} width={32} />
                  <Recharts.Tooltip content={h2hTip} />
                  <Recharts.Line dataKey="eA" stroke={CLR_A} strokeDasharray="4 3" strokeWidth={1.2} strokeOpacity={0.4} dot={false} isAnimationActive={false} />
                  <Recharts.Line dataKey="eB" stroke={CLR_B} strokeDasharray="4 3" strokeWidth={1.2} strokeOpacity={0.4} dot={false} isAnimationActive={false} />
                  <Recharts.Line dataKey="cA" stroke={CLR_A} strokeWidth={2.5} dot={{ r: 3, fill: CLR_A, stroke: "#fff", strokeWidth: 1.5 }} isAnimationActive={false} />
                  <Recharts.Line dataKey="cB" stroke={CLR_B} strokeWidth={2.5} dot={{ r: 3, fill: CLR_B, stroke: "#fff", strokeWidth: 1.5 }} isAnimationActive={false} />
                </Recharts.LineChart>
              </Recharts.ResponsiveContainer>
            </div>
          </div>

          {/* Match record table with totals footer */}
          <div className="card" style={{ padding: 0, overflow: "hidden" }}>
            <div className="flex between center" style={{ padding: 16, borderBottom: "1px solid var(--hair)" }}>
              <div className="eyebrow">{_t("match_record")}</div>
            </div>
            <table className="fbm">
              <thead>
                <tr><th>{_t("season")}</th><th>{_t("home_lbl")}</th><th className="num" style={{ color: CLR_A }}>{a.split(" ")[0]}</th><th className="num text-mut">{_t("exp_short")}</th><th style={{ textAlign: "center" }}></th><th className="num text-mut">{_t("exp_short")}</th><th className="num" style={{ color: CLR_B }}>{b.split(" ")[0]}</th></tr>
              </thead>
              <tbody>
                {meetings.map((m, i) => {
                  const col = m.pA > m.pB ? CLR_A : m.pB > m.pA ? CLR_B : "var(--muted)";
                  const lb = m.pA > m.pB ? a.split(" ")[0] : m.pB > m.pA ? b.split(" ")[0] : _t("draw");
                  return (
                    <tr key={i}>
                      <td className="mono">{m.sn}</td>
                      <td className="text-mut">{m.hm}</td>
                      <td className="num mono" style={{ color: CLR_A, fontWeight: 600 }}>{m.pA}</td>
                      <td className="num mono text-mut">{m.eA.toFixed(1)}</td>
                      <td style={{ textAlign: "center", fontWeight: 700, color: col, fontSize: 12 }}>{lb}</td>
                      <td className="num mono text-mut">{m.eB.toFixed(1)}</td>
                      <td className="num mono" style={{ color: CLR_B, fontWeight: 600 }}>{m.pB}</td>
                    </tr>
                  );
                })}
              </tbody>
              <tfoot>
                <tr style={{ borderTop: "2px solid var(--hair-strong)", fontWeight: 700 }}>
                  <td colSpan={2}>{_t("total")} ({sm.n})</td>
                  <td className="num mono" style={{ color: CLR_A }}>{sm.tpA}</td>
                  <td className="num mono text-mut">{sm.teA}</td>
                  <td style={{ textAlign: "center", color: sm.tpA >= sm.tpB ? CLR_A : CLR_B }}>{(sm.tpA - sm.tpB >= 0 ? "+" : "") + (sm.tpA - sm.tpB)}</td>
                  <td className="num mono text-mut">{sm.teB}</td>
                  <td className="num mono" style={{ color: CLR_B }}>{sm.tpB}</td>
                </tr>
              </tfoot>
            </table>
          </div>
        </>
      )}
    </div>
  );
}

/* ---------- BadRun / Run Evaluator ---------- */
/* ---------- BadRun / Run Evaluator — cumulative funnel + rarity verdict ---------- */
const FBM_SIG = 1.58;
function fbmNormCDF(z) {
  const t = 1 / (1 + 0.2316419 * Math.abs(z));
  const d = 0.3989423 * Math.exp(-z * z / 2);
  const p = d * t * (0.3193815 + t * (-0.3565638 + t * (1.781478 + t * (-1.821256 + t * 1.330274))));
  return z > 0 ? 1 - p : p;
}
function BadRun({ lg, sn, team }) {
  const D = window.__FBM.data;
  const sd = D.seasons[lg][sn] || {};
  const L = window.FBM_LEAGUES[lg];
  const totalRounds = (L.n - 1) * 2;
  const t = sd[team];
  const nP = t ? t.m.length : 0;
  // window controls: [from, to] gameweeks (1-indexed, inclusive), plus quick presets
  const [from, setFrom] = useState(Math.max(1, nP - 4));
  const [to, setTo] = useState(nP);
  React.useEffect(() => { setFrom(Math.max(1, nP - 4)); setTo(nP); }, [team, lg, sn, nP]);
  if (!t || nP === 0) return <EmptyState L={L} sn={sn} />;

  const lo = Math.max(1, Math.min(from, to));
  const hi = Math.min(nP, Math.max(from, to));
  const preset = (n) => { setFrom(Math.max(1, nP - n + 1)); setTo(nP); };

  // cumulative funnel data over the window (incl. per-match fixture data for the tooltip)
  const funnel = useMemo(() => {
    const rows = [];
    const md = D.model[lg];
    let ca = 0, ce = 0;
    for (let k = lo - 1; k < hi; k++) {
      const m = t.m[k];
      ca += m[2]; ce += m[3];
      const n = k - (lo - 1) + 1;
      const s25 = 0.674 * FBM_SIG * Math.sqrt(n);
      const s3 = 1.88 * FBM_SIG * Math.sqrt(n);
      const isH = m[1] === 1;
      const oppW = (sd[m[0]] && sd[m[0]].w) || 0;
      const myW = t.w || 0;
      let pm = null;
      if (md && myW > 0 && oppW > 0) {
        const pp = window.FBM_probs(md, isH ? myW : oppW, isH ? oppW : myW);
        pm = isH ? pp : [pp[2], pp[1], pp[0]];
      }
      rows.push({
        gw: m[4], act: +ca.toFixed(1), exp: +ce.toFixed(1), res: m[2],
        opp: m[0], isH, mp: m[2], me: m[3], pm,
        z_hi3: +(ce + s3).toFixed(1), z_hi25: +(ce + s25).toFixed(1),
        z_lo25: +Math.max(0, ce - s25).toFixed(1), z_lo3: +Math.max(0, ce - s3).toFixed(1)
      });
    }
    return rows;
  }, [t, lo, hi, sd, lg]);

  const nGames = hi - lo + 1;
  const totA = funnel.length ? funnel[funnel.length - 1].act : 0;
  const totE = funnel.length ? funnel[funnel.length - 1].exp : 0;
  const df = totA - totE;

  // rarity verdict — window prob → effective windows → per-season → 1 in N
  const verdict = useMemo(() => {
    if (nGames <= 0 || df === 0) return null;
    const z = Math.abs(df) / (FBM_SIG * Math.sqrt(nGames));
    const pWindow = (1 - fbmNormCDF(z)) * 100;
    const kEff = Math.max(1, Math.round(2 * (totalRounds - nGames + 1) / (nGames + 1)));
    const runPct = kEff > 1 ? (1 - Math.pow(1 - pWindow / 100, kEff)) * 100 : pWindow;
    const nWindows = Math.floor(totalRounds / nGames);
    const seasonPct = nWindows > 1 ? (1 - Math.pow(1 - runPct / 100, nWindows)) * 100 : runPct;
    const oneIn = seasonPct > 0 ? Math.max(1, Math.round(100 / seasonPct)) : 999;
    return { over: df >= 0, seasonPct, oneIn };
  }, [df, nGames, totalRounds]);

  const RES = { 3: "#1F8A5B", 1: "#D8A03D", 0: "#C2492F" };

  /* Original run-evaluator inspector: fixture + wages + cumulative actual/expected/± + per-game result + model W/D/L */
  const runTip = (p) => {
    if (!p.active || !p.payload || !p.payload.length) return null;
    const d = p.payload[0].payload;
    if (d.mp == null) return null;
    const rClr = d.mp === 3 ? "var(--pos)" : d.mp === 1 ? "var(--amber)" : "var(--neg)";
    const homeN = d.isH ? team : d.opp, awayN = d.isH ? d.opp : team;
    const wHm = (sd[homeN] && sd[homeN].w) || 0, wAw = (sd[awayN] && sd[awayN].w) || 0;
    const df3 = (d.act - d.exp).toFixed(1);
    return (
      <div className="charttip" style={{ borderLeft: `4px solid ${rClr}` }}>
        <div className="flex center gap-2" style={{ fontWeight: 600, marginBottom: 2 }}>
          <Crest name={homeN} size={14} />{homeN} <span className="text-mut" style={{ fontWeight: 400 }}>{_t("vs")}</span> <Crest name={awayN} size={14} />{awayN}
          <span className="text-mut" style={{ fontWeight: 400, fontSize: "0.85em" }}>{_t("col_gw")} {d.gw}</span>
        </div>
        {wHm > 0 && wAw > 0 ? <div className="mono text-mut" style={{ fontSize: 10, marginBottom: 2 }}>{L.cur}{wHm}M {_t("vs")} {L.cur}{wAw}M</div> : null}
        <div>{_t("actual_vs")}<b>{d.act}</b></div>
        <div>{_t("expected_colon")}<b>{d.exp}</b></div>
        <div style={{ color: d.act >= d.exp ? "var(--pos)" : "var(--neg)", fontWeight: 600 }}>{(d.act >= d.exp ? "+" : "") + df3} {_t("pts_lc")}</div>
        <div style={{ borderTop: "1px solid var(--hair)", marginTop: 4, paddingTop: 4, fontSize: 10 }}>
          <span style={{ color: rClr, fontWeight: 700 }}>{d.mp === 3 ? _t("win") : d.mp === 1 ? _t("draw") : _t("loss")}</span>
          <span className="text-mut"> ({d.mp} {_t("pts_lc")}, {_t("exp_short")} {d.me.toFixed(1)})</span>
          {d.pm ? (
            <div className="flex gap-2 mono" style={{ marginTop: 3 }}>
              <span style={{ color: "var(--pos)", fontWeight: 600 }}>{_t("w_short")} {Math.round(d.pm[0] * 100)}%</span>
              <span style={{ color: "var(--amber)", fontWeight: 600 }}>{_t("d_short")} {Math.round(d.pm[1] * 100)}%</span>
              <span style={{ color: "var(--neg)", fontWeight: 600 }}>{_t("l_short")} {Math.round(d.pm[2] * 100)}%</span>
            </div>
          ) : null}
        </div>
      </div>
    );
  };

  return (
    <div className="col gap-4">
      <div className="section-head">
        <div>
          <div className="eyebrow">{L.name} · {sn}</div>
          <h2>{_t("tab_badrun")}</h2>
          <AboutTab infoKey="info_badrun" />
        </div>
        <div className="flex gap-2" style={{ flexWrap: "wrap" }}>
          <button onClick={() => preset(5)} className={"chip " + (nGames === 5 && hi === nP ? "is-active" : "")}>{_t("last5_btn")}</button>
          <button onClick={() => preset(10)} className={"chip " + (nGames === 10 && hi === nP ? "is-active" : "")}>{_t("last10_btn")}</button>
          <button onClick={() => { setFrom(1); setTo(nP); }} className={"chip " + (lo === 1 && hi === nP ? "is-active" : "")}>{_t("all")}</button>
        </div>
      </div>

      <div className="flex gap-3 center" style={{ flexWrap: "wrap" }}>
        <label className="flex center gap-2 text-mut" style={{ fontSize: 12 }}>{_t("from")} {_t("col_gw")}
          <select className="field" value={lo} onChange={e => setFrom(+e.target.value)}>
            {Array.from({ length: nP }, (_, i) => i + 1).map(g => <option key={g} value={g}>{t.m[g - 1][4]}</option>)}
          </select>
        </label>
        <label className="flex center gap-2 text-mut" style={{ fontSize: 12 }}>{_t("to")}
          <select className="field" value={hi} onChange={e => setTo(+e.target.value)}>
            {Array.from({ length: nP }, (_, i) => i + 1).map(g => <option key={g} value={g}>{t.m[g - 1][4]}</option>)}
          </select>
        </label>
        <span className="mono text-mut" style={{ fontSize: 12 }}>{nGames} {_t("games")}</span>
      </div>

      {verdict ? (
        <div className="card" style={{ padding: 20, borderLeft: `4px solid ${verdict.over ? "var(--pos)" : "var(--neg)"}` }}>
          <div className="flex center gap-3" style={{ flexWrap: "wrap" }}>
            <div className={"bignum " + (verdict.over ? "delta-up" : "delta-down")}>{df >= 0 ? "+" : ""}{df.toFixed(1)}</div>
            <div>
              <div style={{ fontWeight: 600 }}>{_tf("actual_vs_expected", { a: totA, e: totE.toFixed(1), n: nGames, f: t.m[lo - 1][4], t: t.m[hi - 1][4], total: totalRounds })}</div>
              <div className="text-mut" style={{ fontSize: 13, marginTop: 3 }}>
                {_tf("run_verdict_short", { n: nGames, dir: _t(verdict.over ? "overperformance" : "underperformance"), qual: _t(verdict.over ? "or_more" : "or_worse"), pct: Math.min(99.9, verdict.seasonPct).toFixed(1) + "%" })}{verdict.oneIn >= 2 ? <> — <b style={{ color: "var(--ink)" }}>{_tf("roughly_1_in_n", { n: verdict.oneIn })}</b></> : null}
              </div>
            </div>
          </div>
        </div>
      ) : null}

      <div className="card" style={{ padding: 18 }}>
        <div className="eyebrow" style={{ marginBottom: 12 }}>{_t("actual")} {_t("vs")} {_t("expected")}</div>
        <div style={{ width: "100%", height: 320 }}>
          <Recharts.ResponsiveContainer>
            <Recharts.ComposedChart data={funnel} margin={{ top: 10, right: 24, bottom: 10, left: 0 }}>
              <Recharts.CartesianGrid stroke="var(--hair)" strokeDasharray="2 4" vertical={false} />
              <Recharts.XAxis dataKey="gw" tickLine={false} axisLine={false} tick={{ fill: "var(--muted)", fontSize: 10 }} />
              <Recharts.YAxis tickLine={false} axisLine={false} tick={{ fill: "var(--muted)", fontSize: 10 }} width={32} />
              <Recharts.Tooltip content={runTip} />
              {/* funnel: outer 3-97 light, inner 25-75 stronger */}
              <Recharts.Area dataKey="z_hi3" stroke="none" fill="var(--pos)" fillOpacity={0.06} isAnimationActive={false} activeDot={false} />
              <Recharts.Area dataKey="z_hi25" stroke="none" fill="var(--pos)" fillOpacity={0.10} isAnimationActive={false} activeDot={false} />
              <Recharts.Area dataKey="z_lo25" stroke="none" fill="var(--neg)" fillOpacity={0.10} isAnimationActive={false} activeDot={false} />
              <Recharts.Area dataKey="z_lo3" stroke="none" fill="var(--neg)" fillOpacity={0.06} isAnimationActive={false} activeDot={false} />
              <Recharts.Line type="monotone" dataKey="exp" stroke="var(--muted)" strokeWidth={1.6} strokeDasharray="5 4" dot={false} isAnimationActive={false} />
              <Recharts.Line type="monotone" dataKey="act" stroke="var(--ink)" strokeWidth={2.4} isAnimationActive={false}
                dot={(p) => { const r = funnel[p.index]; return r ? <circle key={p.index} cx={p.cx} cy={p.cy} r={3} fill={RES[r.res]} stroke="#fff" strokeWidth={1.2} /> : null; }}
                activeDot={{ r: 4 }} />
            </Recharts.ComposedChart>
          </Recharts.ResponsiveContainer>
        </div>
        <div className="flex gap-4 center text-mut" style={{ fontSize: 11, marginTop: 8, flexWrap: "wrap" }}>
          <span className="flex center gap-2"><i style={{ width: 16, height: 2.5, background: "var(--ink)" }} />{_t("actual")}</span>
          <span className="flex center gap-2"><i style={{ width: 16, borderTop: "2px dashed var(--muted)" }} />{_t("expected")}</span>
          <span className="flex center gap-2"><i style={{ width: 14, height: 10, background: "var(--pos)", opacity: 0.2, borderRadius: 2 }} />{_t("overperf_50_75")} · {_t("overperf_75_97")}</span>
          <span className="flex center gap-2"><i style={{ width: 14, height: 10, background: "var(--neg)", opacity: 0.2, borderRadius: 2 }} />{_t("underperf_25_50")} · {_t("underperf_3_25")}</span>
        </div>
      </div>

      <div className="card" style={{ padding: 0, overflow: "hidden" }}>
        <table className="fbm">
          <thead><tr><th className="rk">{_t("col_hash")}</th><th className="num">{_t("col_gw")}</th><th>{_t("opponent")}</th><th>{_t("col_venue")}</th><th className="num">{_t("col_pts")}</th><th className="num">{_t("col_exp")}</th><th className="num">Δ</th></tr></thead>
          <tbody>
            {t.m.slice(lo - 1, hi).map((m, i) => (
              <tr key={i}>
                <td className="rk">{lo + i}</td>
                <td className="num">{m[4]}</td>
                <td><div className="team-cell"><Crest name={m[0]} size={18} /><span>{m[0]}</span></div></td>
                <td className="text-mut">{m[1] === 1 ? _t("home_lbl") : _t("away_lbl")}</td>
                <td className="num"><b>{m[2]}</b></td>
                <td className="num text-mut">{m[3].toFixed(2)}</td>
                <td className="num" style={{ color: (m[2] - m[3]) >= 0 ? "var(--pos)" : "var(--neg)", fontWeight: 700 }}>{(m[2] - m[3]) >= 0 ? "+" : ""}{(m[2] - m[3]).toFixed(2)}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

function EmptyState({ L, sn }) {
  return <div className="card" style={{ padding: 48, textAlign: "center" }}>
    <div className="text-mut">{_t("not_in_league")} {sn}.</div>
  </div>;
}

/* ---------- Overperformance (explorer) — 3 metrics from cumulative, trailing windows ---------- */
function fbmPval(cumOP, nMatches) {
  if (nMatches <= 0 || cumOP === 0) return 1;
  const z = Math.abs(cumOP) / (FBM_SIG * Math.sqrt(nMatches));
  return 2 * (1 - fbmNormCDF(z));
}
function Overperformance({ lg, sn, team, setTeam }) {
  const D = window.__FBM.data;
  const L = window.FBM_LEAGUES[lg];
  const teams = (D.cumulative && D.cumulative[lg]) || {};
  const seasonsAsc = useMemo(() => Object.keys(D.seasons[lg] || {}).sort(), [lg]);
  const totalRounds = (L.n - 1) * 2;
  const [mode, setMode0] = useState(() => {
    const h = window.hashGet && window.hashGet("om");
    return ["pts", "norm", "ms"].indexOf(h) >= 0 ? h : "pts";
  });   // pts | norm | ms
  const [win, setWin0] = useState(() => {
    const h = window.hashGet && window.hashGet("ow");
    return ["10y", "5y", "3y"].indexOf(h) >= 0 ? h : "10y";
  });       // 10y | 5y | 3y
  const setMode = (v) => { setMode0(v); window.hashSet && window.hashSet({ om: v }); };
  const setWin = (v) => { setWin0(v); window.hashSet && window.hashSet({ ow: v }); };
  const winN = win === "10y" ? 10 : win === "5y" ? 5 : 3;

  // per-season entry: sd = [season, ?, expPts, actPts]; overperf = sd[3]-sd[2]
  const trailing = (td) => { const arr = (td && td[3]) || []; return winN >= arr.length ? arr : arr.slice(arr.length - winN); };
  const summary = (td) => {
    const sds = trailing(td);
    if (!sds.length) return { v: 0, ns: 0 };
    let cumOP = 0, cumExp = 0;
    sds.forEach(s => { cumOP += s[3] - s[2]; cumExp += s[2]; });
    const nS = sds.length;
    if (mode === "pts") return { v: Math.round(cumOP), ns: nS };
    if (mode === "norm") { const avg = cumExp / nS; return { v: avg > 0 ? Math.round((cumOP / nS) / avg * 1000) / 10 : 0, ns: nS }; }
    const p = fbmPval(cumOP, nS * totalRounds);
    return { v: Math.round((cumOP >= 0 ? 1 : -1) * (100 - p * 100)), ns: nS };
  };
  const ranked = useMemo(() => Object.entries(teams).map(([n, td]) => {
    const s = summary(td); return { n, v: s.v, ns: s.ns };
  }).filter(x => x.ns > 0).sort((a, b) => b.v - a.v), [teams, mode, win]);

  const defaults = ranked.slice(0, 3).map(x => x.n);
  const [sel, setSel] = useState(() => {
    const h = ((window.hashGet && window.hashGet("ex")) || "").split(",").filter(t => teams[t]);
    return h.length ? h : defaults;
  });
  const firstLg = React.useRef(true);
  React.useEffect(() => { if (firstLg.current) { firstLg.current = false; return; } setSel((team && teams[team]) ? [team] : ranked.slice(0, 3).map(x => x.n)); }, [lg]);
  React.useEffect(() => { if (sel.length && window.hashSet) window.hashSet({ ex: sel.join(",") }); }, [sel]);
  const colors = ["#C2492F", "#1E40AF", "#0E8A55", "#C5277A", "#E5A02D"];
  const sfx = mode === "pts" ? " pts" : mode === "norm" ? "%" : "";
  const tog = (n) => setSel(p => p.includes(n) ? (p.length > 1 ? p.filter(x => x !== n) : p) : (p.length < 5 ? [...p, n] : p));

  // per-season chart
  const seasonChart = useMemo(() => seasonsAsc.map(s => {
    const r = { s };
    sel.forEach(t => {
      const sd = teams[t] && teams[t][3].find(x => x[0] === s);
      if (!sd) return;
      const d = sd[3] - sd[2];
      r[t] = mode === "pts" ? Math.round(d) : mode === "norm" ? (sd[2] > 0 ? Math.round(d / sd[2] * 1000) / 10 : 0) : Math.round((d >= 0 ? 1 : -1) * (100 - fbmPval(d, totalRounds) * 100));
    });
    return r;
  }), [sel, teams, mode, seasonsAsc]);

  // trailing cumulative chart
  const cumChart = useMemo(() => seasonsAsc.map((s, si) => {
    const r = { s };
    sel.forEach(t => {
      const td = teams[t]; if (!td) return;
      const start = Math.max(0, si - winN + 1);
      let cumOP = 0, cumExp = 0, n = 0;
      for (let i = start; i <= si; i++) { const sd = td[3].find(x => x[0] === seasonsAsc[i]); if (sd) { cumOP += sd[3] - sd[2]; cumExp += sd[2]; n++; } }
      if (n === 0) return;
      r[t] = mode === "pts" ? Math.round(cumOP) : mode === "norm" ? (cumExp / n > 0 ? Math.round((cumOP / n) / (cumExp / n) * 1000) / 10 : 0) : Math.round((cumOP >= 0 ? 1 : -1) * (100 - fbmPval(cumOP, n * totalRounds) * 100));
    });
    return r;
  }), [sel, teams, mode, win, seasonsAsc]);

  const modes = [
    { k: "pts", l: _t("extra_pts"), tip: _t("raw_overperf_tip") },
    { k: "norm", l: _t("normalized"), tip: _t("norm_tip") },
    { k: "ms", l: _t("man_score"), tip: _t("ms_tip") }
  ];

  // value formatter per mode
  const fmtV = (v) => (v >= 0 ? "+" : "") + v + (mode === "norm" ? "%" : "");
  const single = sel.length === 1;

  /* Season-tracker visual semantics: per-team block, crest + name in team colour, value + context */
  const opTip = (kind) => (p) => {
    if (!p.active || !p.payload || !p.payload.length) return null;
    const d = p.payload[0].payload;
    const s = d.s;
    const blocks = sel.map((t, i) => {
      const color = colors[i % colors.length];
      const v = d[t];
      if (v == null) return null;
      const td = teams[t];
      const sd = td && td[3].find(x => x[0] === s);
      return (
        <div key={t}>
          <div className="flex center gap-2" style={{ fontWeight: 700, color, marginBottom: 2 }}>
            <Crest name={t} size={14} />{t}
          </div>
          <div style={{ color: v >= 0 ? "var(--pos)" : "var(--neg)", fontWeight: 600 }}>
            {fmtV(v)} {mode === "pts" ? _t("pts_lc") : mode === "ms" ? "" : ""}
          </div>
          {kind === "season" && sd ? (
            <div className="text-mut" style={{ fontSize: 10 }}>
              {_t("actual_vs")}{sd[3]} · {_t("expected_colon")}{sd[2].toFixed(1)}
            </div>
          ) : null}
          {kind === "cum" ? (
            <div className="text-mut" style={{ fontSize: 10 }}>{_tf("trailing_nyr", { n: winN })}</div>
          ) : null}
        </div>
      );
    }).filter(Boolean);
    if (!blocks.length) return null;
    const border = single && blocks.length === 1 && d[sel[0]] != null
      ? (d[sel[0]] >= 0 ? "var(--pos)" : "var(--neg)")
      : "var(--hair-strong)";
    return (
      <div className="charttip" style={{ borderLeft: `4px solid ${border}` }}>
        <div style={{ fontWeight: 700, marginBottom: 4 }}>{_t("season")} {s}</div>
        <div className="col" style={{ gap: 6 }}>
          {blocks.map((bk, k) => (
            <div key={k} style={k > 0 ? { borderTop: "1px solid var(--hair)", paddingTop: 6 } : null}>{bk}</div>
          ))}
        </div>
      </div>
    );
  };

  return (
    <div className="col gap-4">
      <div className="section-head">
        <div>
          <div className="eyebrow">{L.name}</div>
          <h2>{_t("tab_explorer")}</h2>
          <AboutTab infoKey="info_explorer" />
        </div>
      </div>

      <div className="flex gap-3 center" style={{ flexWrap: "wrap", position: "sticky", top: 0, zIndex: 15, background: "var(--bg)", padding: "6px 0" }}>
        <div className="flex gap-1">
          {modes.map(m => <button key={m.k} title={m.tip} onClick={() => setMode(m.k)} className={"chip " + (mode === m.k ? "is-active" : "")}>{m.l}</button>)}
        </div>
        <div className="flex gap-1" style={{ marginLeft: "auto" }}>
          {[["10y", _t("trailing_10")], ["5y", _t("trailing_5")], ["3y", _t("trailing_3")]].map(([k, l]) => <button key={k} onClick={() => setWin(k)} className={"chip " + (win === k ? "is-active" : "")}>{l}</button>)}
        </div>
      </div>

      <div className="flex gap-4" style={{ alignItems: "flex-start", flexWrap: "wrap" }}>
        <div className="card" style={{ padding: 8, width: 210, flexShrink: 0, flexGrow: 1, maxWidth: "100%" }}>
          <div style={{ maxHeight: 520, overflowY: "auto" }}>
            {ranked.map(t => {
              const idx = sel.indexOf(t.n);
              return (
                <div key={t.n} onClick={() => tog(t.n)}
                  className="flex between center"
                  style={{ cursor: "pointer", padding: "5px 8px", borderRadius: 6, fontSize: 12.5, fontWeight: idx >= 0 ? 700 : 500, background: idx >= 0 ? colors[idx] + "22" : "transparent", color: idx >= 0 ? colors[idx] : "var(--ink)" }}>
                  <span className="flex center gap-2" style={{ minWidth: 0 }}><Crest name={t.n} size={16} /><span style={{ overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{t.n}</span><span className="text-mut" style={{ fontWeight: 400 }}>({t.ns})</span></span>
                  <span style={{ color: t.v >= 0 ? "var(--pos)" : "var(--neg)", flexShrink: 0 }}>{t.v >= 0 ? "+" : ""}{t.v}{sfx}</span>
                </div>
              );
            })}
          </div>
        </div>

        <div className="col gap-4" style={{ flex: "1 1 260px", minWidth: 0 }}>
          <div className="card" style={{ padding: 18 }}>
            <div className="eyebrow" style={{ marginBottom: 12 }}>{_t("season_by_season")}</div>
            <div style={{ width: "100%", height: 240 }}>
              <Recharts.ResponsiveContainer>
                <Recharts.BarChart data={seasonChart} margin={{ top: 10, right: 20, bottom: 10, left: 0 }}>
                  <Recharts.CartesianGrid stroke="var(--hair)" strokeDasharray="2 4" vertical={false} />
                  <Recharts.XAxis dataKey="s" tickLine={false} axisLine={false} tick={{ fill: "var(--muted)", fontSize: 10 }} />
                  <Recharts.YAxis tickLine={false} axisLine={false} tick={{ fill: "var(--muted)", fontSize: 10 }} width={34} />
                  <Recharts.ReferenceLine y={0} stroke="var(--hair-strong)" />
                  <Recharts.Tooltip content={opTip("season")} cursor={{ fill: "var(--bg-sunken)" }} />
                  {sel.map((t, i) => <Recharts.Bar key={t} dataKey={t} fill={colors[i % colors.length]} fillOpacity={0.85} radius={[3, 3, 0, 0]} isAnimationActive={false} />)}
                </Recharts.BarChart>
              </Recharts.ResponsiveContainer>
            </div>
          </div>

          <div className="card" style={{ padding: 18 }}>
            <div className="eyebrow" style={{ marginBottom: 12 }}>{_tf("trailing_nyr", { n: winN })} · {mode === "ms" ? _t("man_score") : mode === "norm" ? _t("normalized") : _t("cumulative")}</div>
            <div style={{ width: "100%", height: 240 }}>
              <Recharts.ResponsiveContainer>
                <Recharts.LineChart data={cumChart} margin={{ top: 10, right: 20, bottom: 10, left: 0 }}>
                  <Recharts.CartesianGrid stroke="var(--hair)" strokeDasharray="2 4" vertical={false} />
                  <Recharts.XAxis dataKey="s" tickLine={false} axisLine={false} tick={{ fill: "var(--muted)", fontSize: 10 }} />
                  <Recharts.YAxis tickLine={false} axisLine={false} tick={{ fill: "var(--muted)", fontSize: 10 }} width={34} />
                  <Recharts.ReferenceLine y={0} stroke="var(--hair-strong)" />
                  <Recharts.Tooltip content={opTip("cum")} />
                  {sel.map((t, i) => <Recharts.Line key={t} type="monotone" dataKey={t} stroke={colors[i % colors.length]} strokeWidth={2.2} dot={{ r: 3, fill: colors[i % colors.length], strokeWidth: 0 }} connectNulls isAnimationActive={false} />)}
                </Recharts.LineChart>
              </Recharts.ResponsiveContainer>
            </div>
            <div className="flex gap-3 center" style={{ fontSize: 11, marginTop: 8, flexWrap: "wrap", color: "var(--muted)" }}>
              {sel.map((t, i) => <span key={t} className="flex center gap-2"><i style={{ width: 14, height: 3, background: colors[i % colors.length], borderRadius: 2 }} /><Crest name={t} size={14} />{t}</span>)}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

/* ---------- Calculator — wage sliders + team pickers + swap, real ordered logit ---------- */
function Calculator({ lg, sn, setLg }) {
  const D = window.__FBM.data;
  const L = window.FBM_LEAGUES[lg];
  const cur = D.currentSeason;
  const teamWages = useMemo(() => {
    const s = D.seasons[lg][cur] || {};
    return Object.keys(s).filter(t => s[t].w > 0).map(t => ({ n: t, w: s[t].w })).sort((a, b) => b.w - a.w);
  }, [lg, cur]);
  const wmax = Math.max(50, Math.ceil((teamWages[0]?.w || 100) / 10) * 10);
  const [hW, setHW] = useState(() => teamWages[0]?.w || 100);
  const [aW, setAW] = useState(() => teamWages[Math.min(4, teamWages.length - 1)]?.w || 50);
  const [hT, setHT] = useState("");
  const [aT, setAT] = useState("");
  React.useEffect(() => {
    setHW(teamWages[0]?.w || 100);
    setAW(teamWages[Math.min(4, teamWages.length - 1)]?.w || 50);
    setHT(""); setAT("");
  }, [lg]);

  const model = D.model[lg];
  const [pH, pD, pA] = window.FBM_probs(model, hW, aW);
  const hExp = pH * 3 + pD, aExp = pA * 3 + pD;
  const ratio = Math.log2(hW / aW);

  const pick = (side, name) => {
    const tw = teamWages.find(t => t.n === name);
    if (!tw) { side === "h" ? setHT("") : setAT(""); return; }
    if (side === "h") { setHT(name); setHW(tw.w); } else { setAT(name); setAW(tw.w); }
  };
  const swap = () => { const w = hW, t = hT; setHW(aW); setHT(aT); setAW(w); setAT(t); };

  const SidePanel = ({ side, label, w, setW, team, tint }) => (
    <div className="card" style={{ padding: 20, flex: 1, minWidth: 0 }}>
      <div className="flex between center" style={{ marginBottom: 14 }}>
        <div className="eyebrow" style={{ color: tint }}>{label}</div>
        {team ? <div className="flex center gap-2"><Crest name={team} size={20} /><span style={{ fontWeight: 600, fontSize: 13 }}>{team}</span></div> : null}
      </div>
      <div className="bignum" style={{ color: tint }}>{L.cur}{w}M</div>
      <input type="range" min="1" max={wmax} value={w} onChange={e => { setW(+e.target.value); side === "h" ? setHT("") : setAT(""); }}
        style={{ width: "100%", marginTop: 14, accentColor: tint }} />
      <select className="field" value={team} onChange={e => pick(side, e.target.value)} style={{ width: "100%", marginTop: 12 }}>
        <option value="">{_t("custom_select")}</option>
        {teamWages.map(t => <option key={t.n} value={t.n}>{t.n} · {L.cur}{t.w}M</option>)}
      </select>
    </div>
  );

  return (
    <div className="col gap-4">
      <div className="section-head">
        <div>
          <div className="eyebrow">{L.name}</div>
          <h2>{_t("tab_calc")}</h2>
          <div className="text-mut" style={{ fontSize: 13, marginTop: 6, maxWidth: 560 }}>{_t("calc_desc")}</div>
          <AboutTab infoKey="info_calc" />
        </div>
        {setLg ? <LeagueSelector lg={lg} onChange={setLg} /> : null}
      </div>

      <div className="flex gap-3 center" style={{ alignItems: "stretch", flexWrap: "wrap" }}>
        <SidePanel side="h" label={_t("home_lbl")} w={hW} setW={setHW} team={hT} tint="var(--accent)" />
        <button onClick={swap} title="Swap" className="chip" style={{ alignSelf: "center", padding: "10px 14px" }}>⇄</button>
        <SidePanel side="a" label={_t("away_lbl")} w={aW} setW={setAW} team={aT} tint="var(--cobalt)" />
      </div>

      <div className="card" style={{ padding: 24 }}>
        <div className="eyebrow" style={{ marginBottom: 12 }}>{_t("home_win")} · {_t("draw")} · {_t("away_win")}</div>
        <ProbBar pH={pH} pD={pD} pA={pA} />
        <div className="flex between mono" style={{ marginTop: 12, fontSize: 12 }}>
          <span style={{ color: "var(--accent)" }}><b>{_t("home_win")}</b> {Math.round(pH * 100)}%</span>
          <span className="text-mut">{_t("draw")} {Math.round(pD * 100)}%</span>
          <span style={{ color: "var(--cobalt)" }}><b>{_t("away_win")}</b> {Math.round(pA * 100)}%</span>
        </div>
        <div className="flex between center" style={{ marginTop: 24, paddingTop: 20, borderTop: "1px solid var(--hair)", flexWrap: "wrap", gap: 16 }}>
          <div>
            <div className="eyebrow" style={{ marginBottom: 6 }}>{_t("expected")}</div>
            <div style={{ fontSize: 14 }}>{_t("exp_pts_match")}<b className="mono">{hExp.toFixed(2)}</b> · {_t("away_lbl")} <b className="mono">{aExp.toFixed(2)}</b></div>
          </div>
          <div style={{ textAlign: "right" }}>
            <div className="eyebrow" style={{ marginBottom: 6 }}>{_t("wage_ratio")}</div>
            <div className="bignum" style={{ fontSize: 28 }}>{(hW / aW).toFixed(2)}×</div>
            <div className="text-mut mono" style={{ fontSize: 12, marginTop: 4 }}>log₂ {ratio >= 0 ? "+" : ""}{ratio.toFixed(2)}</div>
          </div>
        </div>
      </div>
    </div>
  );
}

/* ---------- Methodology ---------- */
function Methodology() {
  const D = window.__FBM.data;
  const L = window.FBM_LEAGUES;
  const order = window.FBM_LG_ORDER || Object.keys(D.model);
  const params = order.filter(lg => D.model[lg]).map(lg => ({
    lg, name: L[lg].name, ...D.model[lg]
  }));
  const P = ({ children }) => <p className="text-mut" style={{ fontSize: 14, lineHeight: 1.65, marginTop: 8 }}>{children}</p>;
  return (
    <div className="col gap-4">
      <div className="section-head">
        <div>
          <h2>{_t("meth_title")}</h2>
        </div>
      </div>
      <div className="card" style={{ padding: 32, maxWidth: 820 }}>
        <div className="col gap-6">
          <div>
            <h3 style={{ fontSize: 18 }}>{_t("meth_why_wages")}</h3>
            <P>{_t("meth_why_wages_p1")}</P>
            <P>{_t("meth_why_wages_p2")}</P>
          </div>

          <div>
            <h3 style={{ fontSize: 18 }}>{_t("meth_model")}</h3>
            <P>{_t("meth_model_p1")}<i>{_t("meth_ologit")}</i>{_t("meth_model_p1b")}</P>
            <div className="card mono" style={{ padding: "14px 20px", background: "var(--bg-sunken)", fontSize: 15, marginTop: 10 }}>
              x = log₂(w<sub>A</sub> / w<sub>H</sub>)
            </div>
            <P>{_t("meth_model_p2_s1")}<i>x</i>{_t("meth_model_p2_s2")}<i>x</i>{_t("meth_model_p2_s3")}β{_t("meth_model_p2_s4")}θ₁{_t("and")}θ₂{_t("meth_model_p2_s5")}</P>
            <div className="card mono" style={{ padding: "14px 20px", background: "var(--bg-sunken)", fontSize: 15, lineHeight: 1.9, marginTop: 10 }}>
              P(home) = 1 − σ(θ₂ + β·x)<br />
              P(draw) = σ(θ₂ + β·x) − σ(θ₁ + β·x)<br />
              P(away) = σ(θ₁ + β·x)
            </div>
            <P>{_t("meth_model_p3_s1")}<i>z</i>{_t("meth_model_p3_s2")}<sup>−z</sup>{_t("meth_model_p3_s3")}<sub>2</sub>{_t("meth_model_p3_s4")}</P>
          </div>

          <div>
            <h3 style={{ fontSize: 18, marginBottom: 10 }}>{_t("meth_params")}</h3>
            <P>{_t("meth_params_p1")}</P>
            <div className="card" style={{ padding: 0, overflow: "hidden", marginTop: 10 }}>
              <table className="fbm">
                <thead><tr><th>{_t("league")}</th><th className="num">β</th><th className="num">θ₁</th><th className="num">θ₂</th></tr></thead>
                <tbody>
                  {params.map(p => (
                    <tr key={p.lg}>
                      <td style={{ fontWeight: 500 }}>{p.name}</td>
                      <td className="num mono">{p.beta != null ? p.beta.toFixed(3) : "–"}</td>
                      <td className="num mono">{p.theta1 != null ? p.theta1.toFixed(3) : "–"}</td>
                      <td className="num mono">{p.theta2 != null ? p.theta2.toFixed(3) : "–"}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          <div>
            <h3 style={{ fontSize: 18 }}>{_t("meth_budget_forecast")}</h3>
            <P>{_t("meth_budget_p1")}</P>
          </div>

          <div>
            <h3 style={{ fontSize: 18 }}>{_t("meth_updated_forecast")}</h3>
            <P>{_t("meth_updated_p1")}</P>
          </div>

          <div>
            <h3 style={{ fontSize: 18 }}>{_t("meth_position_probs")}</h3>
            <P>{_tf("meth_position_p1", { joint: _t("meth_joint") })}</P>
          </div>

          <div>
            <h3 style={{ fontSize: 18 }}>{_t("meth_overperf_metrics")}</h3>
            <P>{_tf("meth_overperf_intro", { overperf: _t("overperformance") })}</P>
            <P><b>{_t("meth_extra_pts_raw")}</b> {_t("actual")} − {_t("expected")}</P>
            <P><b>{_t("meth_norm_overperf")}</b> {_t("meth_norm_explain")}</P>
            <P><b>{_t("meth_ms_title")}</b> {_tf("meth_ms_where_p", { p: "p" })} {_t("meth_ms_sigma")}</P>
          </div>

          <div>
            <h3 style={{ fontSize: 18 }}>{_t("meth_sources")}</h3>
            <P><b>{_t("match_results")}:</b> {_t("data_results_source")}</P>
            <P><b>{_t("wage_data")}:</b> {_t("data_wages_source")}</P>
            <P><b>{_t("coverage")}:</b> {_t("data_coverage_text")}</P>
          </div>

          <div style={{ borderTop: "1px solid var(--hair)", paddingTop: 20 }}>
            <div className="eyebrow" style={{ marginBottom: 10 }}>{_t("meth_reference")}</div>
            <P>
              {_t("meth_ref_intro")} <a href="https://footballbeyondmoney.uk/paper.pdf" target="_blank" rel="noopener">{_t("meth_ref_title")}</a><br />
              {_t("contact")}<a href="mailto:hello@footballbeyondmoney.uk">hello@footballbeyondmoney.uk</a>
            </P>
          </div>
        </div>
      </div>
    </div>
  );
}

/* ---------- Data & Sources ---------- */
function DataSources({ lg, sn, snList, setSn }) {
  const D = window.__FBM.data;
  const sd = D.seasons[lg][sn] || {};
  const L = window.FBM_LEAGUES[lg];
  const sorted = Object.entries(sd).sort((a, b) => b[1].w - a[1].w);

  return (
    <div className="col gap-4">
      <div className="section-head">
        <div>
          <div className="eyebrow">{L.name} · {sn}</div>
          <h2>{_t("data_title")}</h2>
        </div>
        <SeasonStepper sn={sn} snList={snList} onChange={setSn} />
      </div>

      {(D.meta && D.meta.wage_status && D.meta.wage_status[lg] && D.meta.wage_status[lg][sn] === "stale") ? (
        <StaleBanner lg={lg} sn={sn} />
      ) : null}

      <div className="eyebrow">{_t("data_sources_title")}</div>
      <div className="grid-cards">
        <SourceCard title={_t("match_results")} src="football-data.co.uk" detail={_t("data_results_source")} />
        <SourceCard title={_t("wage_data")} src="Capology" detail={_t("data_wages_source")} />
        <SourceCard title="API" src="football-data.org" detail={_t("data_api_source")} />
        <SourceCard title={_t("data_coverage_title")} src="26,810" detail={_t("data_coverage_text")} />
      </div>

      <WageEvolution lg={lg} L={L} snList={snList} />

      <div className="card" style={{ padding: 0, overflow: "hidden" }}>
        <div className="flex between center" style={{ padding: 16, borderBottom: "1px solid var(--hair)" }}>
          <div>
            <div className="eyebrow">{_t("data_wages_title")} · {sn}</div>
            <div className="text-mut" style={{ fontSize: 12, marginTop: 2 }}>{_t("data_wages_subtitle")}</div>
          </div>
          <span className="mono text-mut" style={{ fontSize: 11 }}>{_t("total")}: {L.cur}{sorted.reduce((s, [, t]) => s + t.w, 0)}M</span>
        </div>
        <table className="fbm">
          <thead><tr><th className="rk">{_t("col_hash")}</th><th>{_t("data_team_col")}</th><th className="num">{_t("data_wage_col")}</th><th className="num">%</th><th></th></tr></thead>
          <tbody>
            {sorted.map(([n, t], i) => {
              const total = sorted.reduce((s, [, x]) => s + x.w, 0);
              const pct = (t.w / total) * 100;
              return (
                <tr key={n}>
                  <td className="rk">{i + 1}</td>
                  <td><div className="team-cell"><Crest name={n} size={22} /><span style={{ fontWeight: 500 }}>{n}</span></div></td>
                  <td className="num"><b>{L.cur}{t.w}M</b></td>
                  <td className="num text-mut">{pct.toFixed(1)}%</td>
                  <td><span style={{ display: "inline-block", height: 6, width: pct * 4 + "px", maxWidth: "100%", background: "var(--accent)", borderRadius: 2 }} /></td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
}

/* Wage evolution across seasons — up to 3 teams, gaps when not in league */
function WageEvolution({ lg, L, snList }) {
  const D = window.__FBM.data;
  const snAsc = useMemo(() => snList.slice().sort(), [snList]);
  const allTeams = useMemo(() => {
    const set = new Set();
    snAsc.forEach(s => Object.keys(D.seasons[lg][s] || {}).forEach(t => set.add(t)));
    return [...set].sort();
  }, [lg, snAsc]);
  const [sel, setSel] = useState(() => [L.def]);
  React.useEffect(() => { setSel([L.def]); }, [lg]);

  const rows = useMemo(() => snAsc.map(s => {
    const r = { sn: s };
    sel.forEach(t => {
      const td = (D.seasons[lg][s] || {})[t];
      r[t] = td && td.w > 0 ? td.w : null;
    });
    return r;
  }), [snAsc, sel, lg]);

  const colors = ["#C2492F", "#1E40AF", "#0E8A55"];

  return (
    <div className="card" style={{ padding: 18 }}>
      <div className="flex between center" style={{ marginBottom: 12, flexWrap: "wrap", gap: 8 }}>
        <div>
          <div className="eyebrow">{_t("wage_evolution")}</div>
          <div className="text-mut" style={{ fontSize: 12, marginTop: 4 }}>{_t("wage_evolution_sub")}</div>
        </div>
        <select className="field" value="" onChange={e => {
          const t = e.target.value;
          if (!t || sel.includes(t)) return;
          setSel(sel.length >= 3 ? [...sel.slice(1), t] : [...sel, t]);
        }}>
          <option value="">{_t("compare_add")}</option>
          {allTeams.filter(t => !sel.includes(t)).map(t => <option key={t} value={t}>{t}</option>)}
        </select>
      </div>
      <div className="flex gap-2" style={{ flexWrap: "wrap", marginBottom: 10 }}>
        {sel.map((t, i) => (
          <button key={t} className="chip is-active" style={{ background: colors[i % colors.length], borderColor: colors[i % colors.length] }}
            onClick={() => sel.length > 1 && setSel(sel.filter(x => x !== t))}>
            <Crest name={t} size={14} /> {t} {sel.length > 1 ? "×" : ""}
          </button>
        ))}
      </div>
      <div style={{ width: "100%", height: 260 }}>
        <Recharts.ResponsiveContainer>
          <Recharts.LineChart data={rows} margin={{ top: 10, right: 24, bottom: 10, left: 0 }}>
            <Recharts.CartesianGrid stroke="var(--hair)" strokeDasharray="2 4" vertical={false} />
            <Recharts.XAxis dataKey="sn" tickLine={false} axisLine={false} tick={{ fill: "var(--muted)", fontSize: 10 }} />
            <Recharts.YAxis tickLine={false} axisLine={false} tick={{ fill: "var(--muted)", fontSize: 10 }} width={44} tickFormatter={v => L.cur + v + "M"} />
            <Recharts.Tooltip
              contentStyle={{ background: "var(--bg-card)", border: "1px solid var(--hair-strong)", borderRadius: 10, fontSize: 12 }}
              formatter={(v, name) => [L.cur + v + "M", name]}
            />
            {sel.map((t, i) => (
              <Recharts.Line key={t} type="monotone" dataKey={t} stroke={colors[i % colors.length]} strokeWidth={2.2}
                dot={{ r: 3, strokeWidth: 0, fill: colors[i % colors.length] }} connectNulls={false} isAnimationActive={false} />
            ))}
          </Recharts.LineChart>
        </Recharts.ResponsiveContainer>
      </div>
    </div>
  );
}

function SourceCard({ title, src, detail }) {
  return (
    <div className="card" style={{ padding: 18 }}>
      <div className="eyebrow">{title}</div>
      <div className="display" style={{ fontSize: 22, marginTop: 6 }}>{src}</div>
      <div className="text-mut" style={{ fontSize: 12, marginTop: 8 }}>{detail}</div>
    </div>
  );
}

/* ---------- History — W/D/L result distribution vs league average ---------- */
function History({ lg, snList, team, setTeam }) {
  const D = window.__FBM.data;
  const L = window.FBM_LEAGUES[lg];
  const [venue, setVenue] = useState("all");   // all | home | away
  const [period, setPeriod] = useState("all");  // all | 5y | 3y
  const [sel, setSel] = useState(() => (team ? [team] : []));
  React.useEffect(() => { setSel(team ? [team] : []); }, [lg]);

  const seasonsDesc = useMemo(() => snList.slice().sort().reverse(), [snList]);
  const periodSeasons = useMemo(() => period === "all" ? seasonsDesc : seasonsDesc.slice(0, period === "5y" ? 5 : 3), [seasonsDesc, period]);

  // count W/D/L for a team across periodSeasons with venue filter
  const dist = (name) => {
    let w = 0, d = 0, l = 0;
    periodSeasons.forEach(s => {
      const td = D.seasons[lg][s] && D.seasons[lg][s][name];
      if (!td) return;
      td.m.forEach(m => {
        if (venue === "home" && m[1] !== 1) return;
        if (venue === "away" && m[1] !== 0) return;
        if (m[2] === 3) w++; else if (m[2] === 1) d++; else l++;
      });
    });
    const n = w + d + l;
    return { w, d, l, n, wp: n ? w / n * 100 : 0, dp: n ? d / n * 100 : 0, lp: n ? l / n * 100 : 0 };
  };

  // league average across all teams
  const leagueAvg = useMemo(() => {
    let w = 0, d = 0, l = 0;
    periodSeasons.forEach(s => {
      const sd = D.seasons[lg][s] || {};
      Object.values(sd).forEach(td => td.m.forEach(m => {
        if (venue === "home" && m[1] !== 1) return;
        if (venue === "away" && m[1] !== 0) return;
        if (m[2] === 3) w++; else if (m[2] === 1) d++; else l++;
      }));
    });
    const n = w + d + l;
    return { w, d, l, n, wp: n ? w / n * 100 : 0, dp: n ? d / n * 100 : 0, lp: n ? l / n * 100 : 0 };
  }, [lg, periodSeasons]);

  const allTeams = useMemo(() => {
    const set = new Set();
    periodSeasons.forEach(s => Object.keys(D.seasons[lg][s] || {}).forEach(t => set.add(t)));
    return [...set].sort();
  }, [lg, periodSeasons]);

  const tog = (n) => setSel(p => p.includes(n) ? p.filter(x => x !== n) : (p.length < 3 ? [...p, n] : p));
  const colors = ["#C2492F", "#1E40AF", "#0E8A55"];

  // chart: grouped horizontal bars — league avg + each selected team, 3 categories
  const chartData = [
    { cat: _t("wins"), league: +leagueAvg.wp.toFixed(1) },
    { cat: _t("draws"), league: +leagueAvg.dp.toFixed(1) },
    { cat: _t("losses"), league: +leagueAvg.lp.toFixed(1) }
  ];
  const dists = {};
  sel.forEach(t => { dists[t] = dist(t); });
  sel.forEach(t => {
    chartData[0][t] = +dists[t].wp.toFixed(1);
    chartData[1][t] = +dists[t].dp.toFixed(1);
    chartData[2][t] = +dists[t].lp.toFixed(1);
  });

  const histTip = ({ active, payload, label }) => {
    if (!active || !payload || !payload.length) return null;
    return (
      <div className="charttip">
        <div style={{ fontWeight: 700, marginBottom: 3 }}>{label}</div>
        {payload.map((p, i) => {
          const isTeam = p.dataKey !== "league";
          const clr = isTeam ? colors[sel.indexOf(p.dataKey) % colors.length] : "var(--muted)";
          return (
            <div key={i} className="flex center gap-2" style={{ color: clr }}>
              {isTeam ? <Crest name={p.dataKey} size={14} /> : null}
              <span>{p.name}: <b>{p.value}%</b></span>
            </div>
          );
        })}
      </div>
    );
  };

  return (
    <div className="col gap-4">
      <div className="section-head">
        <div>
          <div className="eyebrow">{_t("tab_history")}</div>
          <h2>{_t("result_distribution")}</h2>
          <AboutTab infoKey="info_history" />
        </div>
        <div className="flex gap-2" style={{ flexWrap: "wrap" }}>
          <div className="flex gap-1">
            {[["all", _t("all")], ["home", _t("home_lbl")], ["away", _t("away_lbl")]].map(([k, l]) => <button key={k} onClick={() => setVenue(k)} className={"chip " + (venue === k ? "is-active" : "")}>{l}</button>)}
          </div>
          <div className="flex gap-1">
            {[["all", _t("all")], ["5y", _t("last_n_seasons") + " 5"], ["3y", _t("last_n_seasons") + " 3"]].map(([k, l]) => <button key={k} onClick={() => setPeriod(k)} className={"chip " + (period === k ? "is-active" : "")}>{l}</button>)}
          </div>
        </div>
      </div>

      <div className="flex gap-2" style={{ flexWrap: "wrap", alignItems: "center" }}>
        <span className="text-mut" style={{ fontSize: 12 }}>{_t("select_teams")}:</span>
        {sel.map((t, i) => (
          <button key={t} onClick={() => tog(t)} className="chip is-active" style={{ background: colors[i] + "22", color: colors[i], borderColor: colors[i] + "55" }}>
            <Crest name={t} size={14} /> {t} ×
          </button>
        ))}
        <select className="field" value="" onChange={e => { if (e.target.value) tog(e.target.value); }}>
          <option value="">{_t("compare_add")}</option>
          {allTeams.filter(t => !sel.includes(t)).map(t => <option key={t} value={t}>{t}</option>)}
        </select>
      </div>

      <div className="card" style={{ padding: 18 }}>
        <div className="eyebrow" style={{ marginBottom: 12 }}>{_t("matches")} · {venue === "all" ? _t("all") : venue === "home" ? _t("home_lbl") : _t("away_lbl")} · {period === "all" ? _t("all") : _t("last_n_seasons") + (period === "5y" ? " 5" : " 3")}</div>
        <div style={{ width: "100%", height: 260 }}>
          <Recharts.ResponsiveContainer>
            <Recharts.BarChart data={chartData} layout="vertical" margin={{ top: 10, right: 24, bottom: 10, left: 40 }} barGap={2} barCategoryGap="24%">
              <Recharts.CartesianGrid stroke="var(--hair)" strokeDasharray="2 4" horizontal={false} />
              <Recharts.XAxis type="number" domain={[0, 100]} tickFormatter={v => v + "%"} tickLine={false} axisLine={false} tick={{ fill: "var(--muted)", fontSize: 10 }} />
              <Recharts.YAxis type="category" dataKey="cat" tickLine={false} axisLine={false} tick={{ fill: "var(--ink)", fontSize: 12, fontWeight: 600 }} width={48} />
              <Recharts.Tooltip content={histTip} cursor={{ fill: "var(--bg-sunken)" }} />
              <Recharts.Bar dataKey="league" name={_t("league_avg")} fill="var(--muted)" fillOpacity={0.4} radius={[0, 3, 3, 0]} isAnimationActive={false} />
              {sel.map((t, i) => <Recharts.Bar key={t} dataKey={t} fill={colors[i % colors.length]} radius={[0, 3, 3, 0]} isAnimationActive={false} />)}
            </Recharts.BarChart>
          </Recharts.ResponsiveContainer>
        </div>
        <div className="flex gap-4 center" style={{ fontSize: 11, marginTop: 6, flexWrap: "wrap", color: "var(--muted)" }}>
          <span className="flex center gap-2"><i style={{ width: 14, height: 10, background: "var(--muted)", opacity: 0.4, borderRadius: 2 }} />{_t("league_avg")}</span>
          {sel.map((t, i) => <span key={t} className="flex center gap-2"><i style={{ width: 14, height: 10, background: colors[i % colors.length], borderRadius: 2 }} />{t}</span>)}
        </div>
      </div>

      <div className="card" style={{ padding: 0, overflow: "hidden" }}>
        <table className="fbm">
          <thead><tr><th>{_t("team")}</th><th className="num">{_t("wins")}</th><th className="num">{_t("draws")}</th><th className="num">{_t("losses")}</th><th className="num">{_t("matches")}</th></tr></thead>
          <tbody>
            <tr>
              <td className="text-mut" style={{ fontWeight: 600 }}>{_t("league_avg")}</td>
              <td className="num">{leagueAvg.wp.toFixed(1)}%</td>
              <td className="num">{leagueAvg.dp.toFixed(1)}%</td>
              <td className="num">{leagueAvg.lp.toFixed(1)}%</td>
              <td className="num text-mut">{leagueAvg.n}</td>
            </tr>
            {sel.map((t, i) => {
              const x = dists[t];
              return (
                <tr key={t}>
                  <td><div className="team-cell"><Crest name={t} size={20} /><span style={{ fontWeight: 600, color: colors[i % colors.length] }}>{t}</span></div></td>
                  <td className="num">{x.w} <span className="text-mut">({x.wp.toFixed(0)}%)</span></td>
                  <td className="num">{x.d} <span className="text-mut">({x.dp.toFixed(0)}%)</span></td>
                  <td className="num">{x.l} <span className="text-mut">({x.lp.toFixed(0)}%)</span></td>
                  <td className="num text-mut">{x.n}</td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
}

Object.assign(window, {
  Predictions, Matches, H2H, BadRun, Overperformance,
  Calculator, Methodology, DataSources, History
});

/* Season Tracker — actual vs expected line chart + standings. */
const { useState, useMemo } = React;

function Tracker({ lg, sn, snList, team, setTeam, setLg, setSn }) {
  const D = window.__FBM.data;
  const seasonData = D.seasons[lg][sn] || {};
  const standings = useMemo(() => computeStandings(seasonData), [seasonData]);
  const L = window.FBM_LEAGUES[lg];
  const cur = L.cur;
  const [view, setView] = useState("pts"); // pts | pos
  const [compare, setCompare] = useState([team]);

  React.useEffect(() => {
    setCompare([team]);
  }, [team, lg, sn]);

  const totalRounds = (L.n - 1) * 2;
  const isCurrent = sn === D.currentSeason;
  // Real precomputed forecasts (current season only): bands = updated, pre = budget
  const bandsFor = (name) => (isCurrent && D.bands[lg] && D.bands[lg][name]) || null;
  const preFor   = (name) => (isCurrent && D.pre[lg]   && D.pre[lg][name])   || null;

  const chartData = useMemo(() => {
    const rows = [];
    for (let i = 0; i < totalRounds; i++) {
      const gw = i + 1;
      const r = { gw };
      compare.forEach(name => {
        const td = seasonData[name];
        if (!td) return;
        const np = td.a.length;
        if (i < np) r[`a_${name}`] = td.a[i];
        if (i < td.e.length) r[`e_${name}`] = td.e[i];
        // budget forecast (pre-season, wages only) — real p10/p50/p90 per GW
        const pre = preFor(name);
        if (pre && pre.p50[i] != null) {
          r[`bmed_${name}`] = pre.p50[i];
          r[`bband_${name}`] = [pre.p10[i], pre.p90[i]];
        }
        // updated forecast — real p10/p50/p90; median floored at last actual, band width 0 for played GWs
        const bands = bandsFor(name);
        if (bands && bands.p50[i] != null) {
          r[`umed_${name}`] = bands.p50[i];
          r[`uband_${name}`] = i < np ? null : [bands.p10[i], bands.p90[i]];
        }
      });
      rows.push(r);
    }
    return rows;
  }, [compare, seasonData, totalRounds, isCurrent, lg]);

  const colors = ["#C2492F", "#1E40AF", "#0E8A55"];
  const RES_COLORS = { 3: "#1F8A5B", 1: "#D8A03D", 0: "#C2492F" };
  const single = compare.length === 1;
  const np0 = seasonData[compare[0]] ? seasonData[compare[0]].a.length : 0;

  /* ---- Position view: actual rank per GW + real final-p50 evolution from pos.hist ---- */
  const allTeams = useMemo(() => Object.keys(seasonData), [seasonData]);
  const posInfo = (isCurrent && D.pos[lg] && D.pos[lg][sn]) || (D.pos[lg] && D.pos[lg][sn]) || null;
  const posData = useMemo(() => {
    if (view !== "pos") return [];
    const rankAt = (name, i) => {
      const scores = allTeams.map(t => {
        const td = seasonData[t];
        const pts = i < td.a.length ? td.a[i] : (td.a[td.a.length - 1] || 0);
        return { t, pts, gd: td.gd || 0 };
      }).sort((x, y) => y.pts !== x.pts ? y.pts - x.pts : y.gd - x.gd);
      return 1 + scores.findIndex(s => s.t === name);
    };
    const hist = (posInfo && posInfo.hist) || [];
    const curOf = (name) => (posInfo && posInfo.cur && posInfo.cur[name] && posInfo.cur[name].p50) || null;
    const rows = [];
    for (let i = 0; i < totalRounds; i++) {
      const gw = i + 1;
      const r = { gw };
      compare.forEach(name => {
        const td = seasonData[name];
        if (!td) return;
        const np = td.a.length;
        if (i < np) {
          r[`p_${name}`] = rankAt(name, i);
          // real projected-final p50 rank at this GW (from Monte Carlo history)
          const h = hist.find(x => x.gw === gw);
          if (h && h.probs[name]) r[`fp_${name}`] = h.probs[name].p50;
          // seed the projection at the last played GW so it connects to the actual line
          if (i === np - 1 && isCurrent) r[`proj_${name}`] = r[`p_${name}`];
        } else if (isCurrent) {
          // future GW: linear interpolation current rank → pos.cur p50 final rank (original semantics)
          const curP50 = curOf(name);
          const startGW = np - 1, endGW = totalRounds - 1;
          if (curP50 != null && np > 0 && endGW > startGW) {
            const startRank = rankAt(name, np - 1);
            const frac = (i - startGW) / (endGW - startGW);
            r[`proj_${name}`] = Math.round((startRank + (curP50 - startRank) * frac) * 10) / 10;
          }
        }
      });
      rows.push(r);
    }
    return rows;
  }, [view, compare, seasonData, allTeams, totalRounds, posInfo, isCurrent]);

  /* zone bands (ReferenceArea) from the app ZONES constant (league-specific) */
  const Z = window.FBM_ZONES[lg];
  const zones = useMemo(() => ([
    { y1: Z.champion[0] - 0.5, y2: Z.champion[1] + 0.5, c: "#D8C24A", lk: "zone_champion" },
    { y1: Z.ucl[0] - 0.5,      y2: Z.ucl[1] + 0.5,      c: "#3D6EF7", lk: "zone_ucl" },
    { y1: Z.uel[0] - 0.5,      y2: Z.uel[1] + 0.5,      c: "#D8843D", lk: "zone_uel" },
    { y1: Z.conf[0] - 0.5,     y2: Z.conf[1] + 0.5,     c: "#2FBF71", lk: "zone_conf" },
    { y1: Z.rel[0] - 0.5,      y2: Z.rel[1] + 0.5,      c: "#E0503C", lk: "zone_rel" }
  ]), [Z]);

  /* Original inspector semantics, per team (works in single and multi mode):
     fixture header (crests + GW + result letter), wages, date, then per-view values. */
  const ordinal = (v) => {
    if ((window._lang || "en") === "es") return v + "º";
    return v + (v === 1 ? "st" : v === 2 ? "nd" : v === 3 ? "rd" : "th");
  };
  const fixtureOf = (name, gw) => {
    const td = seasonData[name];
    if (!td) return null;
    const np = td.a.length;
    const isPast = gw <= np;
    const mData = isPast ? td.m[gw - 1] : null;
    const rData = !isPast && td.r ? td.r.find(x => x[5] === gw) : null;
    const fx = mData || rData;
    const opp = fx ? fx[0] : null;
    const isH = fx ? fx[1] === 1 : true;
    const homeN = isH ? name : opp, awayN = isH ? opp : name;
    const res = mData ? mData[2] : null;
    // model W/D/L from this team's perspective: r[] for future, recomputed for played
    const wHm = (homeN && seasonData[homeN] && seasonData[homeN].w) || 0;
    const wAw = (awayN && seasonData[awayN] && seasonData[awayN].w) || 0;
    let pWDL = rData ? [rData[2], rData[3], rData[4]] : null;
    if (!pWDL && mData && D.model[lg] && wHm > 0 && wAw > 0) {
      const pp = window.FBM_probs(D.model[lg], wHm, wAw);
      pWDL = isH ? pp : [pp[2], pp[1], pp[0]];
    }
    return {
      td, np, isPast, mData, rData, fx, isH, homeN, awayN, res,
      date: mData ? mData[5] : rData ? rData[6] : null,
      wHm, wAw, pWDL
    };
  };
  /* One team's full tooltip block. mode: "pts" | "pos" */
  const teamTipBlock = (name, gw, d, mode, color) => {
    const f = fixtureOf(name, gw);
    if (!f) return null;
    const resL = f.mData ? (f.res === 3 ? _t("w_short") : f.res === 1 ? _t("d_short") : _t("l_short")) : null;
    const mDiff = f.mData ? f.mData[2] - f.mData[3] : 0;
    const band = d[`uband_${name}`];
    return (
      <div key={name}>
        {f.fx ? (
          <div className="flex center gap-2" style={{ fontWeight: 700, marginBottom: 3, flexWrap: "wrap", color: color || "var(--ink)" }}>
            <Crest name={f.homeN} size={14} />{f.homeN} <span className="text-mut" style={{ fontWeight: 400 }}>{_t("vs")}</span> <Crest name={f.awayN} size={14} />{f.awayN}
            <span className="text-mut" style={{ fontWeight: 400, fontSize: "0.85em" }}>{_t("col_gw")}{f.mData && f.mData[4] != null ? f.mData[4] : gw}{resL ? ` (${resL})` : ""}</span>
          </div>
        ) : (
          <div style={{ fontWeight: 700, marginBottom: 3, color: color || "var(--ink)" }}>{name}</div>
        )}
        {f.wHm > 0 && f.wAw > 0 ? <div className="mono text-mut" style={{ fontSize: 10 }}>{cur}{f.wHm}M {_t("vs")} {cur}{f.wAw}M</div> : null}
        {f.date ? <div className="mono text-mut" style={{ fontSize: 10, marginBottom: 2 }}>{dateNice(f.date)}</div> : null}
        {mode === "pts" ? (
          <>
            {d[`a_${name}`] != null ? <div style={{ color: "var(--cobalt)" }}>{_t("actual_vs")}{d[`a_${name}`]} {_t("pts_lc")}</div> : null}
            {d[`umed_${name}`] != null && !f.isPast ? <div style={{ color: "var(--cobalt)", opacity: 0.75 }}>{_t("projected_final")}{Math.round(d[`umed_${name}`])}</div> : null}
            {band && band[1] - band[0] > 0 ? <div className="text-mut">{_t("range_colon")}{Math.round(band[0])}–{Math.round(band[1])}</div> : null}
            {d[`e_${name}`] != null ? <div className="text-mut">{_t("expected_colon")}{Number(d[`e_${name}`]).toFixed(1)}</div> : null}
            {d[`bmed_${name}`] != null ? <div style={{ color: "#968C7A" }}>{_t("budget_forecast")}: {Math.round(d[`bmed_${name}`])}</div> : null}
          </>
        ) : (
          <>
            {d[`p_${name}`] != null ? <div style={{ color: color || "var(--cobalt)" }}>{_t("position")}: <b>{ordinal(d[`p_${name}`])}</b></div> : null}
            {d[`proj_${name}`] != null ? <div style={{ color: color || "var(--cobalt)", opacity: 0.75 }}>{_t("proj_p50")}: {Math.round(d[`proj_${name}`])}</div> : null}
            {single && d[`fp_${name}`] != null ? <div style={{ color: "#D8843D" }}>{_t("final_p50")}: {Math.round(d[`fp_${name}`])}</div> : null}
          </>
        )}
        {f.pWDL ? (
          <div style={{ marginTop: 3 }}>
            <div className="text-mut" style={{ fontSize: 9, marginBottom: 1 }}>{name}:</div>
            <div className="flex gap-2 mono" style={{ fontSize: 10 }}>
              <span style={{ color: "var(--pos)", fontWeight: 600 }}>{_t("w_short")} {Math.round(f.pWDL[0] * 100)}%</span>
              <span style={{ color: "var(--amber)", fontWeight: 600 }}>{_t("d_short")} {Math.round(f.pWDL[1] * 100)}%</span>
              <span style={{ color: "var(--neg)", fontWeight: 600 }}>{_t("l_short")} {Math.round(f.pWDL[2] * 100)}%</span>
            </div>
          </div>
        ) : null}
        {mode === "pts" && f.mData ? (
          <div className="text-mut" style={{ fontSize: 10, marginTop: 2 }}>
            {_t("game")}: {f.mData[2]}{_t("pts_lc")} ({_t("exp_short")} {f.mData[3].toFixed(1)}, {mDiff >= 0 ? "+" : ""}{mDiff.toFixed(1)})
          </div>
        ) : null}
      </div>
    );
  };
  const trackerTip = (mode) => (p) => {
    if (!p.active || !p.payload || !p.payload.length) return null;
    const d = p.payload[0].payload;
    const gw = d.gw;
    if (single) {
      const name = compare[0];
      const f = fixtureOf(name, gw);
      if (!f) return null;
      const border = f.mData ? RES_COLORS[f.res] : "var(--hair-strong)";
      return (
        <div className="charttip" style={{ borderLeft: `4px solid ${border}` }}>
          {teamTipBlock(name, gw, d, mode)}
        </div>
      );
    }
    // multi-team: same visual style as single — per-team block with GW situation + delta vs budget
    const blocks = compare.map((n, i) => {
      const color = colors[i % colors.length];
      const lines = [];
      if (mode === "pts") {
        const a = d[`a_${n}`], e = d[`e_${n}`], bm = d[`bmed_${n}`], um = d[`umed_${n}`];
        const band = d[`uband_${n}`];
        if (a != null) {
          lines.push(<div key="a" style={{ color }}>{_t("actual_vs")}<b>{a}</b> {_t("pts_lc")}</div>);
          if (e != null) {
            const df = a - e;
            lines.push(<div key="df" style={{ color: df >= 0 ? "var(--pos)" : "var(--neg)", fontWeight: 600 }}>{df >= 0 ? "+" : ""}{df.toFixed(1)} {_t("vs_budget").toLowerCase()}</div>);
          }
        } else if (um != null) {
          lines.push(<div key="pr" style={{ color, opacity: 0.8 }}>{_t("projected_final")}{Math.round(um)}</div>);
          if (band && band[1] - band[0] > 0) lines.push(<div key="rg" className="text-mut">{_t("range_colon")}{Math.round(band[0])}–{Math.round(band[1])}</div>);
          if (bm != null) lines.push(<div key="bm" style={{ color: "#968C7A" }}>{_t("budget_forecast")}: {Math.round(bm)}</div>);
        }
      } else {
        const pos = d[`p_${n}`], proj = d[`proj_${n}`];
        const td = seasonData[n];
        const bR = td ? (1 + standings.slice().sort((x, y) => (seasonData[y.n].w || 0) - (seasonData[x.n].w || 0)).findIndex(s => s.n === n)) : null;
        if (pos != null) {
          lines.push(<div key="p" style={{ color }}>{_t("position")}: <b>{ordinal(pos)}</b></div>);
          if (bR) {
            const dfp = bR - pos;
            lines.push(<div key="dfp" style={{ color: dfp >= 0 ? "var(--pos)" : "var(--neg)", fontWeight: 600 }}>{dfp >= 0 ? "+" : ""}{dfp} {_t("vs_budget").toLowerCase()} (#{bR})</div>);
          }
        }
        if (proj != null) lines.push(<div key="pr" style={{ color, opacity: 0.8 }}>{_t("proj_p50")}: {Math.round(proj)}</div>);
      }
      if (!lines.length) return null;
      return (
        <div key={n}>
          <div className="flex center gap-2" style={{ fontWeight: 700, color, marginBottom: 2 }}>
            <Crest name={n} size={14} />{n}
          </div>
          {lines}
        </div>
      );
    }).filter(Boolean);
    if (!blocks.length) return null;
    return (
      <div className="charttip">
        <div style={{ fontWeight: 700, marginBottom: 4 }}>{_t("col_gw")} {gw}</div>
        <div className="col" style={{ gap: 6 }}>
          {blocks.map((b, k) => (
            <div key={k} style={k > 0 ? { borderTop: "1px solid var(--hair)", paddingTop: 6 } : null}>{b}</div>
          ))}
        </div>
      </div>
    );
  };
  const posTip = trackerTip("pos");
  const ptsTip = trackerTip("pts");

  return (
    <div className="col gap-4">
      <div className="section-head">
        <div>
          <div className="eyebrow">{L.name} · {sn}</div>
          <h2>{_t("tab_tracker")}</h2>
          <AboutTab infoKey="info_tracker" />
        </div>
        <div className="flex gap-2 center">
          <SeasonStepper sn={sn} snList={snList} onChange={setSn} />
        </div>
      </div>

      {/* Team chip row — multi-select up to 3 */}
      <div className="card" style={{ padding: 16 }}>
        <div className="flex between center" style={{ marginBottom: 12 }}>
          <div className="eyebrow">{_t("select_teams")}</div>
        </div>
        <div className="flex gap-2" style={{ flexWrap: "wrap" }}>
          {standings.map(s => {
            const active = compare.includes(s.n);
            return (
              <button key={s.n}
                onClick={() => {
                  if (active) {
                    if (compare.length === 1) return;
                    setCompare(compare.filter(x => x !== s.n));
                  } else {
                    if (compare.length >= 3) setCompare([...compare.slice(1), s.n]);
                    else setCompare([...compare, s.n]);
                  }
                }}
                className={"chip " + (active ? "is-active" : "")}>
                <Crest name={s.n} size={16} />
                <span>{s.n}</span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Chart */}
      <div className="card" style={{ padding: 18 }}>
        <div className="flex between" style={{ marginBottom: 12, flexWrap: "wrap", gap: 8, alignItems: "flex-start" }}>
          <div style={{ flex: "1 1 0", minWidth: 180 }}>
            <div className="eyebrow">{view === "pos" ? _t("view_position") : _t("view_points")}</div>
            <div className="text-mut" style={{ fontSize: 12, marginTop: 4 }}>
              {view === "pos"
                ? `${_t("actual_position")} · ${_t("proj_p50")} · ${_t("final_p50")}`
                : `${_t("actual_points")} · ${_t("updated_median")} · ${_t("updated_p10_p90")} · ${_t("budget_median")} · ${_t("budget_p10_p90")} · ${_t("expected_budget")}`}
            </div>
          </div>
          <div className="col" style={{ alignItems: "flex-end", gap: 8, flex: "0 0 auto" }}>
            <div className="flex" style={{ background: "var(--bg-sunken)", borderRadius: 999, padding: 3 }}>
              <button className={"chip " + (view === "pts" ? "is-active" : "")} onClick={() => setView("pts")} style={{ height: 26 }}>{_t("view_points")}</button>
              <button className={"chip " + (view === "pos" ? "is-active" : "")} onClick={() => setView("pos")} style={{ height: 26 }}>{_t("view_position")}</button>
            </div>
            <div className="flex gap-3" style={{ flexWrap: "wrap" }}>
              {compare.map((n, i) => (
                <div key={n} className="flex center gap-2" style={{ fontSize: 12 }}>
                  <span style={{ width: 14, height: 3, background: colors[i % colors.length], borderRadius: 2 }} />
                  <span style={{ fontWeight: 600 }}>{n}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
        <div style={{ width: "100%", height: 380 }}>
          {view === "pos" ? (
          <Recharts.ResponsiveContainer>
            <Recharts.ComposedChart data={posData} margin={{ top: 10, right: 24, bottom: 10, left: 0 }}>
              <Recharts.CartesianGrid stroke="var(--hair)" strokeDasharray="2 4" vertical={false} />
              <Recharts.XAxis dataKey="gw" tickLine={false} axisLine={false} tick={{ fill: "var(--muted)", fontSize: 10 }} interval={2} />
              <Recharts.YAxis reversed domain={[0.5, L.n + 0.5]} ticks={[1, 5, 10, 15, L.n]} allowDecimals={false} tickLine={false} axisLine={false} tick={{ fill: "var(--muted)", fontSize: 10 }} width={32} />
              {zones.map((z, i) => (
                <Recharts.ReferenceArea key={i} y1={z.y1} y2={z.y2} fill={z.c} fillOpacity={0.09} strokeOpacity={0} />
              ))}
              <Recharts.Tooltip content={posTip} />
              {np0 > 0 && np0 < totalRounds ? (
                <Recharts.ReferenceLine x={np0} stroke="var(--hair-strong)" strokeDasharray="3 3" label={{ value: _t("current"), position: "top", fill: "var(--muted)", fontSize: 10 }} />
              ) : null}
              {single ? (
                <Recharts.Line key={"fp_" + compare[0]} type="monotone" dataKey={`fp_${compare[0]}`} stroke="#D8843D" strokeWidth={1.6} strokeDasharray="4 3" dot={false} isAnimationActive={false} connectNulls />
              ) : null}
              {compare.map((n, i) => (
                <Recharts.Line key={"proj_" + n} type="monotone" dataKey={`proj_${n}`} stroke={colors[i % colors.length]} strokeOpacity={0.45} strokeWidth={2.2} dot={false} isAnimationActive={false} connectNulls={false} />
              ))}
              {compare.map((n, i) => (
                <Recharts.Line key={"p_" + n} type="stepAfter" dataKey={`p_${n}`} stroke={colors[i % colors.length]} strokeWidth={2.4} dot={false} activeDot={{ r: 4 }} isAnimationActive={false} connectNulls />
              ))}
            </Recharts.ComposedChart>
          </Recharts.ResponsiveContainer>
          ) : (
          <Recharts.ResponsiveContainer>
            <Recharts.ComposedChart data={chartData} margin={{ top: 10, right: 24, bottom: 10, left: 0 }}>
              <Recharts.CartesianGrid stroke="var(--hair)" strokeDasharray="2 4" vertical={false} />
              <Recharts.XAxis dataKey="gw" tickLine={false} axisLine={false} tick={{ fill: "var(--muted)", fontSize: 10 }} interval={2} />
              <Recharts.YAxis tickLine={false} axisLine={false} tick={{ fill: "var(--muted)", fontSize: 10 }} width={32} />
              <Recharts.Tooltip content={ptsTip} />
              {np0 > 0 && np0 < totalRounds ? (
                <Recharts.ReferenceLine x={np0} stroke="var(--hair-strong)" strokeDasharray="3 3" label={{ value: _t("current"), position: "top", fill: "var(--muted)", fontSize: 10 }} />
              ) : null}
              {compare.map((n, i) => (
                <Recharts.Area key={"bb_" + n} dataKey={`bband_${n}`} stroke="none" fill={single ? "#968C7A" : colors[i % colors.length]} fillOpacity={single ? 0.13 : 0.07} isAnimationActive={false} activeDot={false} />
              ))}
              {compare.map((n, i) => (
                <Recharts.Area key={"ub_" + n} dataKey={`uband_${n}`} stroke="none" fill={colors[i % colors.length]} fillOpacity={single ? 0.15 : 0.07} isAnimationActive={false} activeDot={false} />
              ))}
              {compare.map((n, i) => (
                <Recharts.Line key={"bm_" + n} type="monotone" dataKey={`bmed_${n}`} stroke={single ? "#968C7A" : colors[i % colors.length]} strokeOpacity={single ? 1 : 0.5} strokeWidth={1.5} strokeDasharray="6 4" dot={false} isAnimationActive={false} />
              ))}
              {compare.map((n, i) => (
                <Recharts.Line key={"um_" + n} type="monotone" dataKey={`umed_${n}`} stroke={colors[i % colors.length]} strokeWidth={1.8} strokeDasharray="5 4" dot={false} isAnimationActive={false} />
              ))}
              {compare.map((n, i) => (
                <Recharts.Line key={"e_" + n} type="monotone" dataKey={`e_${n}`} stroke={colors[i % colors.length]} strokeOpacity={0.55} strokeWidth={1.2} strokeDasharray="1 4" strokeLinecap="round" dot={false} isAnimationActive={false} />
              ))}
              {compare.map((n, i) => (
                <Recharts.Line key={"a_" + n} type="monotone" dataKey={`a_${n}`} stroke={single ? "#181C22" : colors[i % colors.length]} strokeWidth={2.4}
                  dot={single ? (props => {
                    const td = seasonData[n];
                    const m = td && td.m[props.index];
                    if (!m || props.value == null) return null;
                    return <circle key={"d" + props.index} cx={props.cx} cy={props.cy} r={3} fill={RES_COLORS[m[2]]} stroke="#fff" strokeWidth={1.2} />;
                  }) : false}
                  activeDot={{ r: 4 }} isAnimationActive={false} />
              ))}
            </Recharts.ComposedChart>
          </Recharts.ResponsiveContainer>
          )}
        </div>
        {view === "pos" ? (
          <div className="flex gap-4 center text-mut" style={{ fontSize: 11, marginTop: 10, flexWrap: "wrap" }}>
            {zones.map((z, i) => (
              <span key={i} className="flex center gap-2">
                <span style={{ width: 10, height: 10, borderRadius: 2, background: z.c, opacity: 0.5 }} />{_t(z.lk)}
              </span>
            ))}
          </div>
        ) : null}
      </div>

      {/* Standings table */}
      <div className="card" style={{ padding: 0, overflow: "hidden" }}>
        <div className="flex between center" style={{ padding: 16, borderBottom: "1px solid var(--hair)" }}>
          <div className="eyebrow">{L.name} · {sn}</div>
        </div>
        <div className="scrollx">
          <table className="fbm">
            <thead>
              <tr>
                <th className="rk">{_t("col_hash")}</th>
                <th>{_t("team")}</th>
                <THTip className="num" label={_t("col_gw")} tip={_t("tip_games_played")} />
                <th className="num">{_t("w_short")}</th>
                <th className="num">{_t("d_short")}</th>
                <th className="num">{_t("l_short")}</th>
                <th className="num">GD</th>
                <THTip className="num" label={_t("col_pts")} tip={_t("tip_cur_actual")} />
                <THTip className="num" label={_t("col_exp")} tip={_t("tip_budget_pre_exp")} />
                <THTip className="num" label="Δ" tip={_t("tip_actual_minus_exp")} />
                <th className="num">{_t("data_wage_col")}</th>
                <th>{_t("last5_btn")}</th>
              </tr>
            </thead>
            <tbody>
              {standings.map((s, i) => {
                const dd = s.pts - s.exp;
                const sel = compare.includes(s.n);
                const w = s.m.filter(m => m[2] === 3).length;
                const dr = s.m.filter(m => m[2] === 1).length;
                const lo = s.m.filter(m => m[2] === 0).length;
                return (
                  <tr key={s.n} className={sel ? "is-sel" : ""} onClick={() => setTeam(s.n)} style={{ cursor: "pointer" }}>
                    <td className="rk">
                      <div className="flex center gap-2">
                        <span>{i + 1}</span>
                        <span style={{
                          width: 4, height: 18, borderRadius: 2,
                          background: zoneColor(i + 1, L)
                        }} />
                      </div>
                    </td>
                    <td>
                      <div className="team-cell">
                        <Crest name={s.n} size={22} />
                        <span style={{ fontWeight: sel ? 700 : 500 }}>{s.n}</span>
                      </div>
                    </td>
                    <td className="num">{s.played}</td>
                    <td className="num">{w}</td>
                    <td className="num">{dr}</td>
                    <td className="num">{lo}</td>
                    <td className="num">{s.gd >= 0 ? "+" : ""}{s.gd}</td>
                    <td className="num"><b>{s.pts}</b></td>
                    <td className="num text-mut">{s.exp.toFixed(0)}</td>
                    <td className="num" style={{ color: dd >= 0 ? "var(--pos)" : "var(--neg)", fontWeight: 700 }}>{dd >= 0 ? "+" : ""}{dd.toFixed(1)}</td>
                    <td className="num text-mut">{cur}{s.w}M</td>
                    <td><FormDots matches={s.m} limit={5} /></td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

function zoneColor(rk, L) {
  if (rk <= L.ucl) return "#1E40AF";
  if (rk <= L.ucl + L.uel) return "var(--accent)";
  if (rk <= L.ucl + L.uel + L.ucol) return "#0E8A55";
  if (rk > L.n - L.rel) return "#0B0D10";
  return "transparent";
}

window.Tracker = Tracker;

/* Football Beyond Money — app shell. */
const { useState, useEffect } = React;

const TWEAK_DEFAULTS = /*EDITMODE-BEGIN*/{
  "theme": "stadium",
  "accent": "#C2492F",
  "density": "comfortable"
}/*EDITMODE-END*/;

const GROUPS = [
  { id: "club",   label: "Club",   views: [{ id: "home", label: "Home", i18n: "tab_home" }] },
  { id: "season", label: "Season", views: [
    { id: "tracker",     label: "Tracker",     i18n: "tab_tracker" },
    { id: "matches",     label: "Matches",     i18n: "tab_matches" },
    { id: "predictions", label: "Predictions", i18n: "tab_predictions" }
  ]},
  { id: "form",   label: "Form",   views: [
    { id: "badrun", label: "Run Evaluator", i18n: "tab_badrun" },
    { id: "h2h",    label: "Head to Head", i18n: "tab_h2h" }
  ]},
  { id: "legacy", label: "Legacy", views: [
    { id: "overperformance", label: "Overperformance", i18n: "tab_explorer" },
    { id: "history",         label: "History",         i18n: "tab_history" }
  ]},
  { id: "model",  label: "Model",  views: [
    { id: "calc",   label: "Calculator",  i18n: "tab_calc" },
    { id: "method", label: "Methodology", i18n: "tab_method" },
    { id: "data",   label: "Data",        i18n: "tab_data" }
  ]}
];
/* Group-level labels (no dataset keys — bilingual inline) */
const GROUP_LABELS = {
  club:   ["Club", "Club"],
  season: ["Season", "Temporada"],
  form:   ["Form", "Forma"],
  legacy: ["Legacy", "Legado"],
  model:  ["Model", "Modelo"]
};
function glabel(id) { const e = GROUP_LABELS[id]; return e ? e[(window._li && window._li()) || 0] : id; }
function vlabel(v) { return v.i18n && window._t ? window._t(v.i18n) : v.label; }
const VIEW_TO_GROUP = {};
GROUPS.forEach(g => g.views.forEach(v => { VIEW_TO_GROUP[v.id] = g.id; }));
/* Old-app tab= values → view ids (links never break) */
const LEGACY_TAB_MAP = {
  home: "home", tracker: "tracker", matches: "matches", predictions: "predictions",
  badrun: "badrun", h2h: "h2h", explorer: "overperformance", overperformance: "overperformance",
  calc: "calc", method: "method", data: "data", history: "history"
};
function tabFromHash() {
  const m = location.hash.match(/tab=([a-z0-9]+)/);
  return (m && LEGACY_TAB_MAP[m[1]]) || "home";
}
/* Hash params: read + merge-write (tab, lang, lg, sel, sn preserved) */
function hashGet(k) {
  const m = location.hash.match(new RegExp("[#&]" + k + "=([^&]+)"));
  return m ? decodeURIComponent(m[1]) : null;
}
function hashSet(obj) {
  const cur = {};
  location.hash.replace(/^#/, "").split("&").filter(Boolean).forEach(p => {
    const i = p.indexOf("=");
    if (i > 0) cur[p.slice(0, i)] = p.slice(i + 1);
  });
  Object.keys(obj).forEach(k => {
    if (obj[k] == null || obj[k] === "") delete cur[k];
    else cur[k] = encodeURIComponent(obj[k]);
  });
  const s = Object.keys(cur).map(k => k + "=" + cur[k]).join("&");
  try { history.pushState(null, "", "#" + s); } catch (e) {}
}
window.hashGet = hashGet; window.hashSet = hashSet;
/* Haptics + platform detection (install prompt) */
function hap(ms) { try { if (navigator.vibrate) navigator.vibrate(ms || 10); } catch (e) {} }
const IS_IOS = /iphone|ipad|ipod/i.test(navigator.userAgent);
const IS_STANDALONE = (window.matchMedia && window.matchMedia("(display-mode: standalone)").matches) || window.navigator.standalone === true;

function App() {
  const [data, setData] = useState(null);
  const [welcome, setWelcome] = useState(() => !location.hash);
  const [lg, setLg] = useState(() => {
    const h = hashGet("lg");
    return (h && window.FBM_LEAGUES[h]) ? h : "pl";
  });
  const [sn, setSn] = useState("25/26");
  const [team, setTeam] = useState(() => hashGet("sel") || hashGet("br") || hashGet("h2a") || (hashGet("ex") || "").split(",")[0] || "Liverpool");
  const [tab, setTabRaw] = useState(tabFromHash());
  const [slide, setSlide] = useState({ dir: null, key: 0 });
  const [ptrY, setPtrY] = useState(0);
  const ptrRef = React.useRef(0);
  const [deferredPrompt, setDeferredPrompt] = useState(null);
  const setTab = (v) => {
    setTabRaw(v);
    hashSet({ tab: v });
    window.scrollTo(0, 0);
  };
  const tabRef = React.useRef(tab);
  useEffect(() => { tabRef.current = tab; }, [tab]);

  // Capture install prompt
  useEffect(() => {
    const h = (e) => { e.preventDefault(); setDeferredPrompt(e); };
    window.addEventListener("beforeinstallprompt", h);
    return () => window.removeEventListener("beforeinstallprompt", h);
  }, []);

  // Swipe between sub-views of the active group
  useEffect(() => {
    let start = null;
    const onTS = (ev) => {
      const t = ev.touches[0];
      if (!t) return;
      let el = ev.target, inChart = false;
      while (el) {
        if (el.classList && (el.classList.contains("recharts-surface") || el.classList.contains("chart-wrap") || el.tagName === "TABLE" || el.tagName === "TBODY" || el.tagName === "SELECT" || el.tagName === "INPUT")) { inChart = true; break; }
        el = el.parentElement;
      }
      start = { x: t.clientX, y: t.clientY, time: Date.now(), inChart };
    };
    const onTE = (ev) => {
      if (!start) return;
      const t = ev.changedTouches[0];
      const dx = t.clientX - start.x, dy = t.clientY - start.y;
      const dt = Date.now() - start.time, ic = start.inChart;
      start = null;
      if (ic || dt > 400 || Math.abs(dx) < 120 || Math.abs(dy) > Math.abs(dx) * 0.35) return;
      const cur = tabRef.current;
      const g = GROUPS.find(x => x.id === VIEW_TO_GROUP[cur]);
      if (!g || g.views.length < 2) return;
      const ids = g.views.map(v => v.id);
      const i = ids.indexOf(cur);
      const next = dx < 0 ? ids[(i + 1) % ids.length] : ids[(i - 1 + ids.length) % ids.length];
      setTabRaw(next);
      hashSet({ tab: next });
      window.scrollTo(0, 0);
      setSlide(s => ({ dir: dx < 0 ? "left" : "right", key: s.key + 1 }));
      hap(15);
    };
    document.addEventListener("touchstart", onTS, { passive: true });
    document.addEventListener("touchend", onTE, { passive: true });
    return () => {
      document.removeEventListener("touchstart", onTS);
      document.removeEventListener("touchend", onTE);
    };
  }, []);

  // Pull to refresh
  useEffect(() => {
    let sy = 0;
    const ts = (ev) => { sy = window.scrollY <= 1 ? ev.touches[0].clientY : 0; };
    const tm = (ev) => {
      if (!sy) return;
      const dy = ev.touches[0].clientY - sy;
      if (dy > 0 && window.scrollY <= 1) { ptrRef.current = dy; setPtrY(Math.min(dy * 0.5, 60)); }
    };
    const te = () => {
      if (ptrRef.current > 60) { setPtrY(0); ptrRef.current = 0; window.location.reload(); }
      else { setPtrY(0); ptrRef.current = 0; }
      sy = 0;
    };
    document.addEventListener("touchstart", ts, { passive: true });
    document.addEventListener("touchmove", tm, { passive: true });
    document.addEventListener("touchend", te, { passive: true });
    return () => {
      document.removeEventListener("touchstart", ts);
      document.removeEventListener("touchmove", tm);
      document.removeEventListener("touchend", te);
    };
  }, []);
  useEffect(() => {
    const onPop = () => setTabRaw(tabFromHash());
    window.addEventListener("popstate", onPop);
    return () => window.removeEventListener("popstate", onPop);
  }, []);

  // Tap on any open Recharts tooltip dismisses it; it can reappear on the next hover/touch
  useEffect(() => {
    const restore = (e) => {
      document.querySelectorAll(".recharts-tooltip-wrapper").forEach(w => {
        if (w.style.visibility === "hidden" && !w.contains(e.target)) w.style.visibility = "";
      });
    };
    const dismiss = (e) => {
      let el = e.target;
      while (el) {
        if (el.classList && el.classList.contains("recharts-tooltip-wrapper")) {
          el.style.visibility = "hidden";
          return;
        }
        el = el.parentElement;
      }
    };
    document.addEventListener("touchstart", dismiss, true);
    document.addEventListener("click", dismiss, true);
    document.addEventListener("mousemove", restore, true);
    document.addEventListener("touchstart", restore, false);
    return () => {
      document.removeEventListener("touchstart", dismiss, true);
      document.removeEventListener("click", dismiss, true);
      document.removeEventListener("mousemove", restore, true);
      document.removeEventListener("touchstart", restore, false);
    };
  }, []);
  const tweaks = window.useTweaks ? window.useTweaks(TWEAK_DEFAULTS) : null;
  const t = tweaks ? tweaks[0] : TWEAK_DEFAULTS;
  const setTweak = tweaks ? tweaks[1] : () => {};

  // Apply theme attributes to root
  useEffect(() => {
    const themeMap = { stadium: "light", dark: "dark", broadcast: "broadcast" };
    document.documentElement.setAttribute("data-theme", themeMap[t.theme] || "light");
    document.documentElement.setAttribute("data-density", t.density || "comfortable");
    if (t.accent && /^#/.test(t.accent)) {
      document.documentElement.style.setProperty("--accent", t.accent);
    }
  }, [t.theme, t.accent, t.density]);

  // Load dataset
  useEffect(() => {
    window.FBM_buildDataset().then(d => {
      window.__FBM = window.__FBM || {};
      window.__FBM.data = d;
      window.__FBM.crests = d.crests;
      setData(d);
      const hsn = hashGet("sn");
      const cur = (hsn && d.seasons[lg] && d.seasons[lg][hsn]) ? hsn : d.currentSeason;
      setSn(cur);
      const sd = d.seasons[lg][cur];
      const hsel = hashGet("sel") || hashGet("br") || hashGet("h2a") || (hashGet("ex") || "").split(",")[0];
      if (sd && hsel && sd[hsel]) setTeam(hsel);
      else {
        const defT = window.FBM_LEAGUES[lg].def;
        if (sd && sd[defT]) setTeam(defT);
        else if (sd) setTeam(Object.keys(sd)[0]);
      }
    }).catch(e => {
      console.error("Failed to load dataset", e);
    });
  }, []);

  // Keep team in sync when league changes
  useEffect(() => {
    if (!data) return;
    const sd = data.seasons[lg]?.[sn] || data.seasons[lg]?.[data.currentSeason];
    if (!sd) return;
    if (!sd[team]) {
      const def = window.FBM_LEAGUES[lg].def;
      setTeam(sd[def] ? def : Object.keys(sd)[0]);
    }
  }, [lg, sn, data]);

  // expose currentTeam
  useEffect(() => {
    if (window.__FBM) window.__FBM.currentTeam = team;
  }, [team]);

  // persist context in hash (lg / sel / sn)
  useEffect(() => {
    if (!data || welcome) return;
    hashSet({ lg, sel: team, sn });
  }, [lg, team, sn, data, welcome]);

  if (!data) {
    return <div className="bootloader">{window._t ? window._t("loading") : ""}</div>;
  }

  if (welcome) {
    return (
      <Welcome data={data} onStart={(selLg, selTeam) => {
        setLg(selLg);
        setTeam(selTeam);
        setTabRaw("home");
        setWelcome(false);
        hashSet({ tab: "home", lg: selLg, sel: selTeam, lang: window._lang || "en" });
      }} />
    );
  }

  const snList = Object.keys(data.seasons[lg] || {}).sort().reverse();
  const sd = data.seasons[lg][sn] || {};
  const standingsLite = Object.keys(sd).sort((a, b) => (sd[b].a[sd[b].a.length - 1] || 0) - (sd[a].a[sd[a].a.length - 1] || 0));

  const tabProps = { lg, sn, snList, team, setTeam, setTab, setLg, setSn };

  return (
    <>
      {ptrY > 0 ? (
        <div className="ptr-bar" style={{ height: ptrY }}>
          <span>{ptrY > 30 ? "↻ " + _t("release_refresh") : "↓ " + _t("pull_refresh")}</span>
        </div>
      ) : null}
      <Header
        lg={lg} setLg={setLg}
        sn={sn} setSn={setSn} snList={snList}
        team={team} setTeam={setTeam} teamList={standingsLite}
        data={data}
      />
      <TabStrip tab={tab} setTab={setTab} />
      <SubNav tab={tab} setTab={setTab} />
      <BottomBar tab={tab} setTab={setTab} />

      <div key={slide.key} className={"shell" + (slide.dir ? " slide-" + slide.dir : "")} style={{ padding: "20px 20px 60px" }}>
        {tab === "home" ? <Home {...tabProps} /> :
         tab === "tracker" ? <Tracker {...tabProps} /> :
         tab === "matches" ? <Matches {...tabProps} /> :
         tab === "predictions" ? <Predictions {...tabProps} /> :
         tab === "badrun" ? <BadRun {...tabProps} /> :
         tab === "h2h" ? <H2H {...tabProps} /> :
         tab === "overperformance" ? <Overperformance {...tabProps} /> :
         tab === "calc" ? <Calculator {...tabProps} /> :
         tab === "method" ? <Methodology /> :
         tab === "data" ? <DataSources {...tabProps} /> :
         tab === "history" ? <History {...tabProps} /> :
         null}
      </div>

      <Footer deferredPrompt={deferredPrompt} onInstall={() => {
        if (deferredPrompt) {
          deferredPrompt.prompt();
          deferredPrompt.userChoice.then(() => setDeferredPrompt(null));
        } else {
          alert(_t("ios_install_alert"));
        }
      }} />

      {window.TweaksPanel ? (
        <window.TweaksPanel title="Tweaks">
          <window.TweakSection title="Look & feel">
            <window.TweakRadio
              label="Theme"
              value={t.theme}
              onChange={v => setTweak("theme", v)}
              options={[
                { value: "stadium",   label: "Stadium" },
                { value: "dark",      label: "Pitch Dark" },
                { value: "broadcast", label: "Broadcast" }
              ]}
            />
            <window.TweakColor
              label="Accent"
              value={t.accent}
              onChange={v => setTweak("accent", v)}
              options={["#C2492F", "#1E40AF", "#0E8A55", "#C5277A", "#E5A02D"]}
            />
            <window.TweakRadio
              label="Density"
              value={t.density}
              onChange={v => setTweak("density", v)}
              options={[
                { value: "compact",      label: "Compact" },
                { value: "comfortable",  label: "Comfortable" }
              ]}
            />
          </window.TweakSection>
        </window.TweaksPanel>
      ) : null}
    </>
  );
}

function Welcome({ data, onStart }) {
  const [lang, setLangState] = useState(window._lang || "en");
  const [lg, setLg] = useState("pl");
  const sd = data.seasons[lg][data.currentSeason] || {};
  const teams = Object.keys(sd).filter(t => sd[t].w > 0)
    .sort((a, b) => (sd[b].a[sd[b].a.length - 1] || 0) - (sd[a].a[sd[a].a.length - 1] || 0));
  const [team, setTeam] = useState(window.FBM_LEAGUES["pl"].def);
  useEffect(() => {
    const def = window.FBM_LEAGUES[lg].def;
    setTeam(sd[def] ? def : (teams[0] || ""));
  }, [lg]);
  const pickLang = (l) => {
    window._lang = l;
    try { localStorage.setItem("fbm_lang", l); } catch (e) {}
    setLangState(l);
  };
  return (
    <div className="welcome" style={{ backgroundImage: "linear-gradient(rgba(16,26,43,0.80), rgba(16,26,43,0.93)), url(header-bg.jpeg)" }}>
      <div className="welcome-card">
        <div className="wordmark"><span className="dot" /><span>{_t("app_title")}</span></div>
        <p className="welcome-sub">{_t("app_subtitle")}</p>
        <label className="welcome-lbl">{_t("select_language")}</label>
        <div className="langtoggle" role="group" aria-label={_t("select_language")} style={{ alignSelf: "flex-start" }}>
          {["en", "es"].map(l => (
            <button key={l} className={lang === l ? "is-active" : ""} onClick={() => pickLang(l)}>{l.toUpperCase()}</button>
          ))}
        </div>
        <label className="welcome-lbl">{_t("league")}</label>
        <select className="field" value={lg} onChange={e => setLg(e.target.value)}>
          {window.FBM_LG_ORDER.map(k => <option key={k} value={k}>{window.FBM_LEAGUES[k].name}</option>)}
        </select>
        <label className="welcome-lbl">{_t("team")}</label>
        <select className="field" value={team} onChange={e => setTeam(e.target.value)}>
          {teams.map(t => <option key={t} value={t}>{t}</option>)}
        </select>
        <button className="welcome-start" onClick={() => onStart(lg, team)}>{_t("start")}</button>
      </div>
    </div>
  );
}

function LangToggle() {
  const cur = window._lang || "en";
  return (
    <div className="langtoggle" role="group" aria-label="Language">
      {["en", "es"].map(l => (
        <button key={l}
          className={cur === l ? "is-active" : ""}
          onClick={() => { if (l !== cur) window.FBM_setLang(l); }}>
          {l.toUpperCase()}
        </button>
      ))}
    </div>
  );
}

function Header({ lg, setLg, sn, setSn, snList, team, setTeam, teamList, data }) {
  return (
    <header className="head">
      <div className="shell head-inner">
        <div className="wordmark">
          <span className="dot" />
          <span>{_t("app_title")}</span>
        </div>
        <div className="flex gap-2 center" style={{ flexWrap: "wrap" }}>
          <select className="field" value={team} onChange={e => setTeam(e.target.value)} style={{ minWidth: 170 }}>
            {teamList.map(t => <option key={t}>{t}</option>)}
          </select>
          <select className="field" value={sn} onChange={e => setSn(e.target.value)} style={{ width: 110 }}>
            {snList.map(s => <option key={s}>{s}</option>)}
          </select>
          <LangToggle />
        </div>
      </div>
      <div className="shell" style={{ paddingBottom: 14 }}>
        <LeagueSelector lg={lg} onChange={setLg} />
      </div>
    </header>
  );
}

function TabStrip({ tab, setTab }) {
  const group = VIEW_TO_GROUP[tab];
  return (
    <div className="tabstrip">
      <div className="shell">
        <div className="tabstrip-inner">
          {GROUPS.map(gr => (
            <button key={gr.id}
              className={"tabbtn " + (group === gr.id ? "is-active" : "")}
              onClick={() => setTab(gr.views[0].id)}>
              {glabel(gr.id)}
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}

/* Sub-view pills — own bar so they render on mobile too (tabstrip is hidden there) */
function SubNav({ tab, setTab }) {
  const group = VIEW_TO_GROUP[tab];
  const g = GROUPS.find(x => x.id === group);
  if (!g || g.views.length < 2) return null;
  return (
    <div className="subnavbar">
      <div className="shell">
        <div className="subnav" style={{ padding: "10px 0 12px" }}>
          {g.views.map(v => (
            <button key={v.id}
              className={"seg " + (tab === v.id ? "is-active" : "")}
              onClick={() => setTab(v.id)}>
              {vlabel(v)}
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}

const GROUP_ICONS = {
  club:   <svg width="18" height="18" viewBox="0 0 16 16"><path d="M2.5 8 L8 3 L13.5 8 M4 7 V13 H12 V7" stroke="currentColor" strokeWidth="1.5" fill="none" strokeLinejoin="round" strokeLinecap="round"/></svg>,
  season: <svg width="18" height="18" viewBox="0 0 16 16"><path d="M2 13 L6 8 L9 10.5 L14 4" stroke="currentColor" strokeWidth="1.5" fill="none" strokeLinecap="round" strokeLinejoin="round"/></svg>,
  form:   <svg width="18" height="18" viewBox="0 0 16 16"><path d="M2 12 L5 12 M2 8.5 L8 8.5 M2 5 L11 5" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"/><circle cx="13" cy="11" r="2.2" stroke="currentColor" strokeWidth="1.4" fill="none"/></svg>,
  legacy: <svg width="18" height="18" viewBox="0 0 16 16"><path d="M8 2 L8 14 M4 6 C4 4 6 3.4 8 3.4 C10 3.4 12 4 12 6 M3 14 H13" stroke="currentColor" strokeWidth="1.4" fill="none" strokeLinecap="round"/></svg>,
  model:  <svg width="18" height="18" viewBox="0 0 16 16"><circle cx="8" cy="8" r="5.5" stroke="currentColor" strokeWidth="1.4" fill="none"/><path d="M8 5 V8.4 L10.4 9.8" stroke="currentColor" strokeWidth="1.4" fill="none" strokeLinecap="round"/></svg>
};

function BottomBar({ tab, setTab }) {
  const group = VIEW_TO_GROUP[tab];
  return (
    <nav className="bottombar">
      {GROUPS.map(gr => (
        <button key={gr.id}
          className={group === gr.id ? "is-active" : ""}
          onClick={() => setTab(gr.views[0].id)}>
          {GROUP_ICONS[gr.id]}
          <span>{glabel(gr.id)}</span>
          {group === gr.id ? <span className="bdot"></span> : null}
        </button>
      ))}
    </nav>
  );
}

function Footer({ deferredPrompt, onInstall }) {
  const showInstall = !IS_STANDALONE && (deferredPrompt || IS_IOS);
  return (
    <footer className="hair-top" style={{ padding: "28px 0", color: "var(--muted)", fontSize: 12 }}>
      <div className="shell flex between center" style={{ flexWrap: "wrap", gap: 12 }}>
        <div className="flex center gap-3">
          <span className="dot" style={{ background: "var(--accent)", width: 8, height: 8, borderRadius: 2, display: "inline-block" }} />
          <span>{_t("app_subtitle")} · {_t("footer_leagues")}</span>
        </div>
        <div className="flex gap-4">
          {showInstall ? (
            <button className="linkbtn" onClick={onInstall} style={{ color: "var(--accent)", fontWeight: 600 }}>{_t("install_app")}</button>
          ) : null}
          <button className="linkbtn" onClick={() => window.FBM_setLang("en")} style={{ fontWeight: (window._lang || "en") === "en" ? 700 : 400 }}>EN</button>
          <button className="linkbtn" onClick={() => window.FBM_setLang("es")} style={{ fontWeight: window._lang === "es" ? 700 : 400 }}>ES</button>
          <a href="https://footballbeyondmoney.uk/paper.pdf" target="_blank" rel="noopener">{_t("read_full")} →</a>
        </div>
      </div>
    </footer>
  );
}

ReactDOM.createRoot(document.getElementById("root")).render(<App />);

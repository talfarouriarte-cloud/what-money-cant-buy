/* Home tab — editorial narrative cards keyed to a selected team. */
const { useState, useEffect, useMemo } = React;

function Home({ lg, sn, team, setTeam, setTab, setLg }) {
  const D = window.__FBM.data;
  const seasonData = D.seasons[lg][sn] || {};
  const standings = useMemo(() => computeStandings(seasonData), [seasonData]);
  const t = seasonData[team];
  const L = window.FBM_LEAGUES[lg];
  const cur = L.cur;

  if (!t) {
    return (
      <div className="card" style={{ padding: 40, textAlign: "center" }}>
        <div className="text-mut">{_t("select_team")}</div>
      </div>
    );
  }

  const nP = t.m.length;
  const totalRounds = (L.n - 1) * 2;
  const ap = t.a[nP - 1] || 0;
  const ep = t.e[nP - 1] || 0;
  const df = ap - ep;
  const rank = 1 + standings.findIndex(s => s.n === team);
  const proj = Math.round(ap + (totalRounds - nP) * (ap / Math.max(1, nP)));
  const budgetRank = [...standings].sort((a, b) => b.w - a.w).findIndex(s => s.n === team) + 1;
  const last5 = t.m.slice(-5);
  const formPts = last5.reduce((s, m) => s + m[2], 0);
  const next = t.r[0];

  // Recent run vs expected (last 5 / last 10)
  const runDiff = (n) => t.m.slice(-n).reduce((s, m) => s + (m[2] - m[3]), 0);
  const d5 = runDiff(5), d10 = runDiff(10);

  // Closest upcoming league fixture (across all teams)
  const allUpcoming = useMemo(() => {
    const arr = [];
    Object.entries(seasonData).forEach(([n, d]) => {
      d.r.forEach(r => { if (r[1] === 1) arr.push({ home: n, away: r[0], pW: r[2], pD: r[3], pL: r[4], date: r[6], gw: r[5] }); });
    });
    arr.sort((a, b) => (a.date || "").localeCompare(b.date || ""));
    const nextRound = arr.slice(0, L.n / 2);
    const closest = [...nextRound].sort((a, b) => Math.abs(a.pW - a.pL) - Math.abs(b.pW - b.pL))[0];
    const upset   = [...nextRound].sort((a, b) => Math.abs(b.pW - b.pL) - Math.abs(a.pW - a.pL))[0];
    return { closest, upset };
  }, [seasonData]);

  // Zone probabilities from precomputed pos.cur (≥5%)
  const zoneOdds = useMemo(() => {
    const p = D.pos && D.pos[lg] && D.pos[lg][sn] && D.pos[lg][sn].cur && D.pos[lg][sn].cur[team];
    if (!p) return [];
    const items = [
      { k: "1st", lk: "zone_champion", c: "#D8C24A", v: p["1st"] || 0 },
      { k: "ucl", lk: "zone_ucl", c: "#3D6EF7", v: Math.max(0, (p.ucl || 0) - (p["1st"] || 0)) },
      { k: "uel", lk: "zone_uel", c: "#D8843D", v: p.uel || 0 },
      { k: "conf", lk: "zone_conf", c: "#2FBF71", v: p.ucol || 0 },
      { k: "mid", lk: "zone_mid", c: "#9a938a", v: p.mid || 0 },
      { k: "rel", lk: "zone_rel", c: "#E0503C", v: p.rel || 0 }
    ];
    return items.filter(z => z.v >= 0.05);
  }, [lg, sn, team]);

  const teamColor = "var(--accent)";

  return (
    <div className="col gap-4">
      {/* Billboard hero */}
      <div className="billboard">
        <div className="accent-strip" />
        <div>
          <div className="meta">
            <span>{L.country}</span>
            <span>{L.name}</span>
            <span>{_t("season")} {sn}</span>
            <span>{_tf("after_n_games", { n: nP })}</span>
          </div>
          <h1>{team}</h1>
          <div className="flex gap-4 center" style={{ marginTop: 14, flexWrap: "wrap" }}>
            <Crest name={team} size={56} />
            <div>
              <div className="midnum" style={{ color: "#fff" }}>{ap}<span style={{ opacity: 0.45, fontSize: "0.55em", marginLeft: 6 }}>pts</span></div>
              <div className="mono" style={{ fontSize: 11, color: "rgba(255,255,255,0.6)", letterSpacing: "0.12em", textTransform: "uppercase" }}>{nP}{_t("matches_lc")} · #{rank}</div>
            </div>
            <div style={{ marginLeft: "auto" }}>
              <FormDots matches={t.m} limit={5} />
              <div className="mono" style={{ fontSize: 10, color: "rgba(255,255,255,0.5)", marginTop: 6, textTransform: "uppercase", letterSpacing: "0.1em" }}>{_t("last5")}{formPts} {_t("pts")}</div>
            </div>
          </div>
        </div>
        <div className="col gap-3" style={{ borderLeft: "1px solid rgba(255,255,255,0.12)", paddingLeft: 28 }}>
          <div>
            <div className="eyebrow" style={{ color: "rgba(255,255,255,0.55)" }}>{_t("vs_budget")}</div>
            <div className="midnum" style={{ color: df >= 0 ? "#4FD08A" : "#F76A4E" }}>{df >= 0 ? "+" : ""}{df.toFixed(1)}</div>
            <div className="mono" style={{ fontSize: 11, color: "rgba(255,255,255,0.55)" }}>{_t(df >= 0 ? "overperformance" : "underperformance")}</div>
          </div>
          <div className="flex gap-6" style={{ marginTop: 8, flexWrap: "wrap" }}>
            <div style={{ minWidth: 88 }}>
              <div className="eyebrow" style={{ color: "rgba(255,255,255,0.55)", whiteSpace: "nowrap" }}>{_t("budget_lc")}</div>
              <div className="smnum" style={{ color: "#fff" }}>#{budgetRank}</div>
            </div>
            <div style={{ minWidth: 88 }}>
              <div className="eyebrow" style={{ color: "rgba(255,255,255,0.55)", whiteSpace: "nowrap" }}>{_t("projected_lc")}</div>
              <div className="smnum" style={{ color: "#fff" }}>{proj} {_t("pts")}</div>
            </div>
            <div style={{ minWidth: 88 }}>
              <div className="eyebrow" style={{ color: "rgba(255,255,255,0.55)" }}>{_t("data_wage_col")}</div>
              <div className="smnum" style={{ color: "#fff" }}>{cur}{t.w}M</div>
            </div>
          </div>
        </div>
      </div>

      {/* Card grid — the narrative answers */}
      <AboutTab infoKey="info_home" />

      <div className="grid-cards">
        <NarrativeCard
          q={_tf("card_howis", { team })}
          tab="tracker"
          setTab={setTab}
          color={teamColor}>
          <div className="hero-num">
            <Crest name={team} size={40} />
            <div>
              <div className="midnum">{ap} <span className="text-mut" style={{ fontSize: 14, marginLeft: 4 }}>pts</span></div>
              <div className="text-mut" style={{ fontSize: 12 }}>{_tf("after_n_games", { n: nP })} · {_t("expected_colon")}{ep.toFixed(0)} {_t("pts")}</div>
            </div>
          </div>
          <div className="flex gap-2 center" style={{ marginTop: 12 }}>
            <span className="pill" style={{ background: df >= 0 ? "rgba(27,122,74,0.12)" : "rgba(178,59,42,0.10)", color: df >= 0 ? "var(--pos)" : "var(--neg)", borderColor: "transparent" }}>{df >= 0 ? "+" : ""}{df.toFixed(1)} {_t("vs_budget")}</span>
            <span className="pill ghost">{_t("rank")} #{rank}</span>
            <span className="pill ghost">{_t("budget_lc")} #{budgetRank}</span>
          </div>
          <ZoneBarWrap lg={lg} rank={rank} />
        </NarrativeCard>

        <NarrativeCard
          q={_t("card_next")}
          tab="h2h"
          setTab={setTab}
          color="var(--cobalt)">
          {next ? (
            <>
              <div className="flex center gap-3" style={{ marginBottom: 12 }}>
                <Crest name={team} size={28} />
                <span style={{ fontWeight: 700 }}>{team}</span>
                <span className="mono text-mut" style={{ fontSize: 11 }}>{next[1] === 1 ? "vs" : "@"}</span>
                <span style={{ fontWeight: 700 }}>{next[0]}</span>
                <Crest name={next[0]} size={28} />
              </div>
              <ProbBar pH={next[2]} pD={next[3]} pA={next[4]} />
              <div className="flex between" style={{ marginTop: 10 }}>
                <div className="mono" style={{ fontSize: 11 }}><span className="text-mut">{_t("win")} </span><b>{Math.round(next[2] * 100)}%</b></div>
                <div className="mono" style={{ fontSize: 11 }}><span className="text-mut">{_t("draw")} </span><b>{Math.round(next[3] * 100)}%</b></div>
                <div className="mono" style={{ fontSize: 11 }}><span className="text-mut">{_t("loss")} </span><b>{Math.round(next[4] * 100)}%</b></div>
              </div>
              <div className="text-mut mono" style={{ fontSize: 11, marginTop: 8 }}>{_t("col_gw")}{next[5]} · {dateNice(next[6])}</div>
            </>
          ) : <div className="text-mut">{_t("season_complete")}</div>}
        </NarrativeCard>

        <NarrativeCard
          q={_t("card_mgmt")}
          tab="overperformance"
          setTab={setTab}
          color={df >= 0 ? "var(--pos)" : "var(--neg)"}>
          <div className="hero-num">
            <div className={"bignum " + (df >= 0 ? "delta-up" : "delta-down")}>{df >= 0 ? "+" : ""}{df.toFixed(1)}</div>
            <div>
              <div className="eyebrow">{_t("vs_budget")}</div>
              <div className="text-mut" style={{ fontSize: 12 }}>{_t("budget_lc")} #{budgetRank} · {_t("rank")} #{rank}</div>
            </div>
          </div>
          <div className="flex gap-3" style={{ marginTop: 14 }}>
            <div className="col" style={{ flex: 1 }}>
              <div className="eyebrow">{_t("data_wage_col")}</div>
              <div className="smnum mono">{cur}{t.w}<span className="text-mut" style={{ fontSize: 12 }}>M</span></div>
            </div>
            <div className="col" style={{ flex: 1 }}>
              <div className="eyebrow">{_t("expected")}</div>
              <div className="smnum mono">{ep.toFixed(0)}</div>
            </div>
            <div className="col" style={{ flex: 1 }}>
              <div className="eyebrow">{_t("actual")}</div>
              <div className="smnum mono">{ap}</div>
            </div>
          </div>
        </NarrativeCard>

        <NarrativeCard q={_t("card_run")} tab="badrun" setTab={setTab} color="var(--accent)">
          <div className="hero-num">
            <div className={"bignum " + (d5 >= 0 ? "delta-up" : "delta-down")}>{d5 >= 0 ? "+" : ""}{d5.toFixed(1)}</div>
            <div>
              <div className="eyebrow">{_t("last5_btn")}</div>
              <div className="text-mut" style={{ fontSize: 12 }}>{_t("vs_budget")}</div>
            </div>
          </div>
          <div className="flex" style={{ marginTop: 12 }}>
            <FormDots matches={t.m} limit={5} />
          </div>
          <div className="text-mut mono" style={{ fontSize: 12, marginTop: 8 }}>{_t("last10")}{d10 >= 0 ? "+" : ""}{d10.toFixed(1)} {_t("vs_budget")}</div>
        </NarrativeCard>

        <NarrativeCard q={_t("card_matches")} tab="matches" setTab={setTab} color="var(--ink)">
          {allUpcoming.closest ? (
            <>
              <div className="eyebrow" style={{ marginBottom: 8 }}>{_t("closest_matches")}</div>
              <MiniMatch m={allUpcoming.closest} cur={cur} />
              <div className="eyebrow" style={{ marginTop: 18 }}>{_t("most_uneven")}</div>
              <div style={{ marginTop: 8 }}><MiniMatch m={allUpcoming.upset} cur={cur} /></div>
            </>
          ) : <div className="text-mut">{_t("no_matches")}</div>}
        </NarrativeCard>

        <NarrativeCard q={_t("card_ahead")} tab="predictions" setTab={setTab} color="var(--cobalt)">
          {zoneOdds.length ? (
            <div className="flex gap-2" style={{ flexWrap: "wrap" }}>
              {zoneOdds.map(z => (
                <span key={z.k} className="pill ghost" style={{ borderColor: z.c + "66" }}>
                  <span style={{ width: 8, height: 8, borderRadius: 2, background: z.c, display: "inline-block", marginRight: 6 }} />
                  {_t(z.lk)} <b className="mono" style={{ marginLeft: 4 }}>{Math.round(z.v * 100)}%</b>
                </span>
              ))}
            </div>
          ) : <div className="text-mut">{_t("no_projection")}</div>}
          <div className="text-mut mono" style={{ fontSize: 11, marginTop: 12 }}>{_t("projected_final")}{proj} {_t("pts")}</div>
        </NarrativeCard>
      </div>

      {/* Standings preview */}
      <div className="section-head">
        <div>
          <div className="eyebrow">{L.name} · {sn}</div>
          <h2>{_t("position")}</h2>
        </div>
        <button className="chip" onClick={() => setTab("tracker")}>{_t("tab_tracker")} →</button>
      </div>
      <div className="card" style={{ padding: 0, overflow: "hidden" }}>
        <div className="scrollx">
          <table className="fbm">
            <thead>
              <tr>
                <th className="rk">{_t("col_hash")}</th>
                <th>{_t("team")}</th>
                <th className="num">{_t("col_gw")}</th>
                <th className="num">{_t("col_pts")}</th>
                <th className="num">{_t("col_exp")}</th>
                <th className="num">Δ</th>
                <th className="num">GD</th>
                <th className="num">{_t("data_wage_col")}</th>
                <th>{_t("last5_btn")}</th>
              </tr>
            </thead>
            <tbody>
              {standings.map((s, i) => {
                const dd = s.pts - s.exp;
                const sel = s.n === team;
                return (
                  <tr key={s.n} className={sel ? "is-sel" : ""} onClick={() => setTeam(s.n)} style={{ cursor: "pointer" }}>
                    <td className="rk">{i + 1}</td>
                    <td>
                      <div className="team-cell">
                        <Crest name={s.n} size={22} />
                        <span style={{ fontWeight: sel ? 700 : 500 }}>{s.n}</span>
                      </div>
                    </td>
                    <td className="num">{s.played}</td>
                    <td className="num"><b>{s.pts}</b></td>
                    <td className="num text-mut">{s.exp.toFixed(0)}</td>
                    <td className="num" style={{ color: dd >= 0 ? "var(--pos)" : "var(--neg)" }}>{dd >= 0 ? "+" : ""}{dd.toFixed(1)}</td>
                    <td className="num">{s.gd >= 0 ? "+" : ""}{s.gd}</td>
                    <td className="num text-mut">{cur}{s.w}M</td>
                    <td><FormDots matches={s.m} limit={5} /></td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

function NarrativeCard({ q, tab, setTab, color, children }) {
  return (
    <button
      onClick={() => setTab && setTab(tab)}
      className="card"
      style={{
        padding: "var(--pad)",
        textAlign: "left",
        cursor: "pointer",
        borderLeft: `4px solid ${color}`,
        background: "var(--bg-card)",
        transition: "transform .15s ease, box-shadow .15s ease",
        position: "relative"
      }}
      onMouseEnter={e => e.currentTarget.style.transform = "translateY(-2px)"}
      onMouseLeave={e => e.currentTarget.style.transform = "translateY(0)"}
    >
      <div className="flex between center" style={{ marginBottom: 14 }}>
        <div className="eyebrow" style={{ color }}>{q}</div>
        <span className="mono" style={{ fontSize: 11, color: "var(--muted)" }}>→</span>
      </div>
      {children}
    </button>
  );
}

function ZoneBarWrap({ lg, rank }) {
  const L = window.FBM_LEAGUES[lg];
  return (
    <div style={{ marginTop: 14 }}>
      <div className="zone-bar" title={`Position ${rank}`}>
        <span className="zb-ucl"  style={{ flex: L.ucl }} />
        <span className="zb-uel"  style={{ flex: L.uel }} />
        <span className="zb-conf" style={{ flex: L.ucol }} />
        <span className="zb-mid"  style={{ flex: L.n - L.ucl - L.uel - L.ucol - L.rel }} />
        <span className="zb-rel"  style={{ flex: L.rel }} />
      </div>
      <div className="flex between mono" style={{ fontSize: 9.5, marginTop: 4, color: "var(--muted)", textTransform: "uppercase", letterSpacing: "0.08em" }}>
        <span>{_t("col_ucl")}</span><span>{_t("col_uel")}</span><span>{_t("col_conf")}</span><span>{_t("col_mid")}</span><span>{_t("col_rel")}</span>
      </div>
      <div className="mono" style={{ fontSize: 11, marginTop: 4 }}>
        <span className="text-mut">{_t("current")} </span>#{rank} / {L.n}
      </div>
    </div>
  );
}

function MiniMatch({ m, cur }) {
  const total = m.pW + m.pD + m.pL;
  return (
    <div>
      <div className="flex between center" style={{ marginBottom: 6 }}>
        <span className="flex center gap-2"><Crest name={m.home} size={22} /><span style={{ fontWeight: 600 }}>{m.home}</span></span>
        <span className="mono text-mut" style={{ fontSize: 11 }}>{dateNice(m.date)}</span>
        <span className="flex center gap-2"><span style={{ fontWeight: 600 }}>{m.away}</span><Crest name={m.away} size={22} /></span>
      </div>
      <ProbBar pH={m.pW / total} pD={m.pD / total} pA={m.pL / total} />
    </div>
  );
}

window.Home = Home;

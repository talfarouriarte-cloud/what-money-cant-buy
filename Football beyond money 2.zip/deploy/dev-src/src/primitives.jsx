/* Shared primitives: Crest, LeagueSelector, SeasonStepper, FormDots, ZoneBar, etc. */

const { useState, useEffect, useMemo, useRef } = React;

function AboutTab({ infoKey }) {
  const [open, setOpen] = useState(false);
  const t = window._t || (k => k);
  const text = t(infoKey);
  if (!text || text === infoKey) return null;
  return (
    <div className="abouttab">
      <button className="abouttab-toggle" onClick={() => setOpen(!open)} aria-expanded={open}>
        <span className="abouttab-i">i</span>
        <span>{open ? t("info_hide") : t("info_show")}</span>
        <span className="abouttab-chev" style={{ transform: open ? "rotate(180deg)" : "none" }}>›</span>
      </button>
      {open ? <div className="abouttab-body">{text}</div> : null}
    </div>
  );
}

function InfoNote({ text }) {
  const [open, setOpen] = useState(false);
  return (
    <span style={{ position: "relative", display: "inline-block", marginLeft: 8, verticalAlign: "middle" }}>
      <button className="infodot" onClick={() => setOpen(!open)} aria-label="About this view">?</button>
      {open ? (
        <span className="infopop" onClick={() => setOpen(false)}>{text}</span>
      ) : null}
    </span>
  );
}

function Crest({ name, size = 22, className = "" }) {
  // Real crest image from crests.json; monogram fallback on missing/error
  const url = (window.__FBM && window.__FBM.crests && window.__FBM.crests[name]) || null;
  const [broken, setBroken] = useState(false);
  useEffect(() => { setBroken(false); }, [name]);
  if (url && !broken) {
    return (
      <img
        className={"crest-img " + className}
        src={url}
        alt={name}
        title={name}
        loading="lazy"
        onError={() => setBroken(true)}
        style={{ width: size, height: size, flex: `0 0 ${size}px`, objectFit: "contain", display: "inline-block", verticalAlign: "middle" }}
      />
    );
  }
  // Deterministic color from name
  const hue = useMemo(() => {
    let h = 0;
    for (let i = 0; i < (name || "").length; i++) h = (h * 31 + name.charCodeAt(i)) >>> 0;
    return h % 360;
  }, [name]);
  const initials = (name || "?")
    .replace(/^(FC|AC|AS|SS|RC|US|SC|SD|CD|SK|SV|TSV|VfL|VfB|RB)\s+/i, "")
    .split(/\s+/).filter(Boolean).map(s => s[0]).slice(0, 3).join("").toUpperCase();
  const dim = size + "px";
  const fs = Math.max(8, Math.floor(size * (initials.length > 2 ? 0.30 : 0.42)));
  return (
    <span
      className={"crest-mono " + className}
      title={name}
      style={{
        width: dim, height: dim,
        flex: `0 0 ${dim}`,
        borderRadius: Math.max(4, size * 0.18),
        background: `oklch(0.32 0.05 ${hue})`,
        color: "#fff",
        display: "inline-flex",
        alignItems: "center",
        justifyContent: "center",
        fontFamily: "var(--font-mono)",
        fontWeight: 700,
        fontSize: fs,
        letterSpacing: "-0.02em",
        boxShadow: "inset 0 -1px 0 rgba(0,0,0,0.18), inset 0 1px 0 rgba(255,255,255,0.10)"
      }}
    >{initials}</span>
  );
}

function LeagueSelector({ lg, onChange, dense }) {
  const items = window.FBM_LG_ORDER.map(k => ({ k, name: window.FBM_LEAGUES[k].name, country: window.FBM_LEAGUES[k].country }));
  if (dense) {
    return (
      <select className="field" value={lg} onChange={e => onChange(e.target.value)} style={{ minWidth: 170 }}>
        {items.map(it => <option key={it.k} value={it.k}>{it.country} — {it.name}</option>)}
      </select>
    );
  }
  return (
    <div className="flex gap-2" style={{ flexWrap: "wrap" }}>
      {items.map(it => (
        <button key={it.k}
          onClick={() => onChange(it.k)}
          className={"chip " + (it.k === lg ? "is-active" : "")}>
          <span className="mono" style={{ fontSize: 10, opacity: 0.7 }}>{it.country}</span>
          <span>{it.name}</span>
        </button>
      ))}
    </div>
  );
}

function SeasonStepper({ sn, snList, onChange }) {
  const idx = snList.indexOf(sn);
  return (
    <div className="flex center gap-2">
      <button
        className="chip"
        onClick={() => idx < snList.length - 1 && onChange(snList[idx + 1])}
        disabled={idx >= snList.length - 1}
        style={{ opacity: idx >= snList.length - 1 ? 0.4 : 1, padding: "0 10px" }}
        title="Previous season"
      >‹</button>
      <span className="mono" style={{ fontSize: 13, fontWeight: 700, minWidth: 56, textAlign: "center" }}>{sn}</span>
      <button
        className="chip"
        onClick={() => idx > 0 && onChange(snList[idx - 1])}
        disabled={idx <= 0}
        style={{ opacity: idx <= 0 ? 0.4 : 1, padding: "0 10px" }}
        title="Next season"
      >›</button>
    </div>
  );
}

function FormDots({ matches, limit = 5 }) {
  const last = (matches || []).slice(-limit);
  return (
    <span className="flex gap-2" style={{ gap: 3 }}>
      {last.map((m, i) => {
        const k = m[2] === 3 ? "w" : m[2] === 1 ? "d" : "l";
        const c = k === "w" ? "W" : k === "d" ? "D" : "L";
        return <span key={i} className={"formdot " + k} title={m[5] || ""}>{c}</span>;
      })}
    </span>
  );
}

function ZoneBar({ lg, position }) {
  const L = window.FBM_LEAGUES[lg];
  const segs = [
    { cls: "zb-ucl",  w: L.ucl },
    { cls: "zb-uel",  w: L.uel },
    { cls: "zb-conf", w: L.ucol },
    { cls: "zb-mid",  w: L.n - L.ucl - L.uel - L.ucol - L.rel },
    { cls: "zb-rel",  w: L.rel },
  ];
  return (
    <div className="zone-bar" title={`Position ${position} / ${L.n}`}>
      {segs.map((s, i) => <span key={i} className={s.cls} style={{ flex: s.w }} />)}
    </div>
  );
}

function StatTile({ label, value, sub, tone, big }) {
  const cls = tone === "pos" ? "delta-up" : tone === "neg" ? "delta-down" : "";
  return (
    <div className="card" style={{ padding: "var(--pad)" }}>
      <div className="eyebrow" style={{ marginBottom: 8 }}>{label}</div>
      <div className={big ? "bignum" : "midnum"}><span className={cls}>{value}</span></div>
      {sub ? <div className="text-mut" style={{ fontSize: 12, marginTop: 6 }}>{sub}</div> : null}
    </div>
  );
}

function Sparkline({ points, color = "var(--accent)", height = 32 }) {
  if (!points || points.length < 2) return <svg className="spark" style={{ height }} />;
  const w = 120, h = height;
  const max = Math.max(...points), min = Math.min(...points);
  const span = Math.max(1, max - min);
  const step = w / (points.length - 1);
  const d = points.map((p, i) => `${i === 0 ? "M" : "L"}${(i * step).toFixed(1)},${(h - 4 - ((p - min) / span) * (h - 8)).toFixed(1)}`).join(" ");
  return (
    <svg className="spark" viewBox={`0 0 ${w} ${h}`} preserveAspectRatio="none" style={{ height }}>
      <path d={d} fill="none" stroke={color} strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );
}

function ProbBar({ pH, pD, pA }) {
  const w = Math.round(pH * 100), d = Math.round(pD * 100), l = 100 - w - d;
  return (
    <div className="probbar" style={{
      gridTemplateColumns: `${w}% ${d}% ${l}%`
    }}>
      <span className="pb w">{w}</span>
      <span className="pb d">{d}</span>
      <span className="pb l">{l}</span>
    </div>
  );
}

function MatchScoreCell({ m, lg, season }) {
  // m: [opp, isHome, ptsActual, ptsExp, gw, date] — no scoreline in dataset; show points
  const isH = m[1] === 1;
  const score = m[2] + " pt" + (m[2] === 1 ? "" : "s");
  return (
    <div className="matchcell">
      <div className="home">
        {isH ? <><Crest name={getOurName()} size={20} /><span style={{ fontWeight: 700 }}>{getOurName()}</span></> :
               <><Crest name={m[0]} size={20} /><span>{m[0]}</span></>}
      </div>
      <div className="score">{score}</div>
      <div className="away">
        {isH ? <><span>{m[0]}</span><Crest name={m[0]} size={20} /></> :
               <><span style={{ fontWeight: 700 }}>{getOurName()}</span><Crest name={getOurName()} size={20} /></>}
      </div>
    </div>
  );
}
function getOurName() { return window.__FBM.currentTeam || ""; }

function computeStandings(seasonData) {
  return Object.entries(seasonData)
    .map(([n, d]) => ({
      n,
      pts: d.a[d.a.length - 1] || 0,
      played: d.played || d.m.length,
      gd: d.gd || 0,
      gf: d.gf || 0,
      ga: d.ga || 0,
      w: d.w,
      exp: d.e[d.e.length - 1] || 0,
      m: d.m,
      r: d.r,
      a: d.a, e: d.e
    }))
    .sort((a, b) => b.pts !== a.pts ? b.pts - a.pts : b.gd - a.gd);
}

function fmtMoney(v, cur) {
  if (v == null) return "—";
  return `${cur}${v}M`;
}

function abbrev(name, max = 14) {
  if (!name) return "";
  if (name.length <= max) return name;
  return name.slice(0, max - 1) + "…";
}

function dateNice(s) {
  if (!s) return "";
  try {
    const d = new Date(s + "T12:00:00");
    return d.toLocaleDateString("en-GB", { day: "2-digit", month: "short" });
  } catch (e) { return s; }
}

/* Stale-wage warning banner (meta.wage_status[lg][sn] === "stale") */
function StaleBanner({ lg, sn }) {
  const meta = window.__FBM.data.meta || {};
  const isStale = meta.wage_status && meta.wage_status[lg] && meta.wage_status[lg][sn] === "stale";
  if (!isStale) return null;
  return (
    <div className="card" style={{ padding: "10px 14px", borderLeft: "3px solid var(--amber)", display: "flex", gap: 10, alignItems: "flex-start" }}>
      <span style={{ color: "var(--amber)", fontWeight: 700, fontSize: 13, lineHeight: 1.4 }}>⚠</span>
      <div>
        <div style={{ fontWeight: 700, fontSize: 12 }}>{_t("wage_stale_title")}</div>
        <div className="text-mut" style={{ fontSize: 11, lineHeight: 1.5 }}>{_t("wage_stale_msg")}</div>
      </div>
    </div>
  );
}

/* Tap-tooltip for table headers — one open at a time */
let __thOpenSetters = [];
function THTip({ label, tip, className, style }) {
  const [open, setOpen] = useState(false);
  useEffect(() => {
    __thOpenSetters.push(setOpen);
    return () => { __thOpenSetters = __thOpenSetters.filter(s => s !== setOpen); };
  }, []);
  return (
    <th className={className} style={{ ...(style || {}), cursor: "help", position: "relative" }}
      onClick={(ev) => { ev.stopPropagation(); const next = !open; __thOpenSetters.forEach(s => s(false)); setOpen(next); }}>
      {label}
      {open ? (
        <div style={{ position: "absolute", top: "100%", right: 0, zIndex: 50, background: "var(--ink)", color: "var(--bg-card)", padding: "4px 8px", borderRadius: 6, fontSize: 10, fontWeight: 500, letterSpacing: 0, textTransform: "none", width: "max-content", maxWidth: "min(60vw, 240px)", whiteSpace: "normal", textAlign: "left", lineHeight: 1.4, boxShadow: "0 2px 8px rgba(0,0,0,0.2)" }}>{tip}</div>
      ) : null}
    </th>
  );
}

Object.assign(window, {
  Crest, LeagueSelector, SeasonStepper, FormDots, ZoneBar, InfoNote, AboutTab,
  StatTile, Sparkline, ProbBar, MatchScoreCell,
  computeStandings, fmtMoney, abbrev, dateNice, StaleBanner, THTip
});
